﻿--
-- PostgreSQL database dump
--

\restrict 5o0BL4DGEGNXr52VL33xMJHBmQCaSVpWp7mqTKt1cKZpPZ6qDoZzU920gQ5zV0I

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: complete_task(uuid, text, text, integer, text); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.complete_task(task_uuid uuid, task_stdout text DEFAULT NULL::text, task_stderr text DEFAULT NULL::text, task_exit_code integer DEFAULT NULL::integer, task_error text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    result_uuid UUID;
    task_tenant_id UUID;
    task_agent_id UUID;
BEGIN
    -- Get task details
    SELECT tenant_id, agent_id INTO task_tenant_id, task_agent_id
    FROM tasks WHERE id = task_uuid;
    
    -- Update task status (treat empty-string errors as no-error)
    UPDATE tasks
    SET 
        status = CASE WHEN task_error IS NOT NULL AND length(trim(task_error)) > 0 THEN 'failed' ELSE 'completed' END,
        completed_at = NOW()
    WHERE id = task_uuid;
    
    -- Insert result
    INSERT INTO results (
        tenant_id,
        agent_id,
        task_id,
        stdout,
        stderr,
        exit_code,
        error_message,
        completed,
        result_type
    ) VALUES (
        task_tenant_id,
        task_agent_id,
        task_uuid,
        task_stdout,
        task_stderr,
        task_exit_code,
        task_error,
        true,
        'complete'
    ) RETURNING id INTO result_uuid;
    
    RETURN result_uuid;
END;
$$;


ALTER FUNCTION public.complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text) OWNER TO gla1v3_app;

--
-- Name: FUNCTION complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text) IS 'Mark task as complete and store result';


--
-- Name: get_expiring_certificates(integer); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_expiring_certificates(days_threshold integer DEFAULT 30) RETURNS TABLE(agent_id uuid, hostname text, cert_fingerprint text, cert_expiry timestamp with time zone, days_remaining integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id,
        a.hostname,
        a.cert_fingerprint,
        a.cert_expiry,
        EXTRACT(DAY FROM (a.cert_expiry - NOW()))::INTEGER as days_remaining
    FROM agents a
    WHERE a.cert_expiry IS NOT NULL
    AND a.cert_expiry <= NOW() + (days_threshold || ' days')::INTERVAL
    AND a.cert_status = 'active'
    ORDER BY a.cert_expiry ASC;
END;
$$;


ALTER FUNCTION public.get_expiring_certificates(days_threshold integer) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_expiring_certificates(days_threshold integer); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_expiring_certificates(days_threshold integer) IS 'Get agents with certificates expiring soon';


--
-- Name: get_pending_tasks_for_agent(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) RETURNS TABLE(task_id uuid, task_type text, command text, args jsonb, embedded_type text, embedded_params jsonb, run_once boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Mark tasks as sent and return them atomically
    -- This prevents returning the same task multiple times
    RETURN QUERY
    WITH updated_tasks AS (
        UPDATE tasks
        SET status = 'sent', sent_at = NOW()
        WHERE agent_id = agent_uuid
        AND status = 'pending'
        RETURNING
            tasks.id,
            tasks.task_type,  -- Qualify with table name to avoid ambiguity
            tasks.command,
            tasks.args,
            tasks.embedded_type,
            tasks.embedded_params,
            tasks.run_once,
            tasks.created_at
    )
    SELECT * FROM updated_tasks ORDER BY created_at ASC;
END;
$$;


ALTER FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_pending_tasks_for_agent(agent_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) IS 'Atomically get and mark tasks as sent for an agent';


--
-- Name: get_tenant_stats(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_tenant_stats(tenant_uuid uuid) RETURNS TABLE(total_agents bigint, active_agents bigint, inactive_agents bigint, total_tasks bigint, pending_tasks bigint, completed_tasks bigint, failed_tasks bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        COUNT(DISTINCT a.id),
        COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'active'),
        COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'inactive'),
        COUNT(DISTINCT t.id),
        COUNT(DISTINCT t.id) FILTER (WHERE t.status IN ('pending', 'sent')),
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'completed'),
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'failed')
    FROM tenants tn
    LEFT JOIN agents a ON a.tenant_id = tn.id
    LEFT JOIN tasks t ON t.tenant_id = tn.id
    WHERE tn.id = tenant_uuid
    GROUP BY tn.id;
END;
$$;


ALTER FUNCTION public.get_tenant_stats(tenant_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_tenant_stats(tenant_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_tenant_stats(tenant_uuid uuid) IS 'Get statistics for a specific tenant';


--
-- Name: get_user_tenants(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_user_tenants(user_uuid uuid) RETURNS TABLE(tenant_id uuid, tenant_name text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- If admin, return all tenants
    IF EXISTS (SELECT 1 FROM users WHERE id = user_uuid AND role = 'admin') THEN
        RETURN QUERY
        SELECT t.id, t.name
        FROM tenants t
        WHERE t.active = true
        ORDER BY t.name;
    ELSE
        -- If operator, return only assigned tenants
        RETURN QUERY
        SELECT t.id, t.name
        FROM tenants t
        INNER JOIN user_tenants ut ON ut.tenant_id = t.id
        WHERE ut.user_id = user_uuid
        AND t.active = true
        ORDER BY t.name;
    END IF;
END;
$$;


ALTER FUNCTION public.get_user_tenants(user_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_user_tenants(user_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_user_tenants(user_uuid uuid) IS 'Get all tenants accessible by a user. Admins see all, operators see assigned.';


--
-- Name: log_audit(uuid, uuid, text, text, uuid, jsonb, inet, text); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text DEFAULT NULL::text, p_resource_id uuid DEFAULT NULL::uuid, p_details jsonb DEFAULT NULL::jsonb, p_ip_address inet DEFAULT NULL::inet, p_user_agent text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    log_id UUID;
BEGIN
    INSERT INTO audit_log (
        user_id,
        tenant_id,
        action,
        resource_type,
        resource_id,
        details,
        ip_address,
        user_agent
    ) VALUES (
        p_user_id,
        p_tenant_id,
        p_action,
        p_resource_type,
        p_resource_id,
        p_details,
        p_ip_address,
        p_user_agent
    ) RETURNING id INTO log_id;
    
    RETURN log_id;
END;
$$;


ALTER FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text) OWNER TO gla1v3_app;

--
-- Name: FUNCTION log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text) IS 'Log an audit event';


--
-- Name: mark_stale_agents_inactive(integer); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.mark_stale_agents_inactive(stale_minutes integer DEFAULT 60) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    affected_count INTEGER;
BEGIN
    UPDATE agents
    SET status = 'inactive'
    WHERE status = 'active'
    AND last_seen < NOW() - (stale_minutes || ' minutes')::INTERVAL;
    
    GET DIAGNOSTICS affected_count = ROW_COUNT;
    RETURN affected_count;
END;
$$;


ALTER FUNCTION public.mark_stale_agents_inactive(stale_minutes integer) OWNER TO gla1v3_app;

--
-- Name: FUNCTION mark_stale_agents_inactive(stale_minutes integer); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.mark_stale_agents_inactive(stale_minutes integer) IS 'Mark agents that haven''t checked in as inactive';


--
-- Name: set_current_user(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.set_current_user(user_uuid uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Set for transaction (false = transaction-local, will be cleared after transaction)
    -- The application should use queryWithContext() to ensure proper context per query
    PERFORM set_config('app.current_user_id', user_uuid::text, false);
END;
$$;


ALTER FUNCTION public.set_current_user(user_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION set_current_user(user_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.set_current_user(user_uuid uuid) IS 'Set the current user context for RLS policies. Call this after authentication.';


--
-- Name: update_agent_last_seen(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.update_agent_last_seen(agent_uuid uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE agents
    SET last_seen = NOW()
    WHERE id = agent_uuid;
END;
$$;


ALTER FUNCTION public.update_agent_last_seen(agent_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO gla1v3_app;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_blacklist; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.agent_blacklist (
    agent_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    reason text,
    expires_at timestamp with time zone,
    blacklisted_at timestamp with time zone DEFAULT now(),
    revoked boolean DEFAULT false
);


ALTER TABLE public.agent_blacklist OWNER TO gla1v3_app;

--
-- Name: TABLE agent_blacklist; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.agent_blacklist IS 'Blacklisted agents that are denied access to the C2 server';


--
-- Name: agents; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.agents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    hostname text NOT NULL,
    cn text,
    os text,
    arch text,
    username text,
    ip_address inet,
    latitude double precision,
    longitude double precision,
    geo_country text,
    geo_region text,
    geo_city text,
    cert_fingerprint text,
    cert_issued_at timestamp with time zone,
    cert_expiry timestamp with time zone,
    cert_status text DEFAULT 'active'::text,
    cert_id text,
    status text DEFAULT 'active'::text,
    first_seen timestamp with time zone DEFAULT now(),
    last_seen timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT agents_cert_status_check CHECK ((cert_status = ANY (ARRAY['active'::text, 'revoked'::text, 'expired'::text, 'pending'::text]))),
    CONSTRAINT agents_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text, 'compromised'::text, 'removed'::text])))
);


ALTER TABLE public.agents OWNER TO gla1v3_app;

--
-- Name: TABLE agents; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.agents IS 'Compromised hosts running Gla1v3 agents';


--
-- Name: COLUMN agents.cert_id; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.agents.cert_id IS 'Certificate ID from CA service for dynamic cert management';


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    action text NOT NULL,
    resource_type text,
    resource_id uuid,
    details jsonb,
    ip_address inet,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO gla1v3_app;

--
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.audit_log IS 'Audit trail of all administrative actions';


--
-- Name: results; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.results (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    task_id uuid NOT NULL,
    stdout text,
    stderr text,
    exit_code integer,
    error_message text,
    stream_index integer DEFAULT 0,
    result_type text DEFAULT 'complete'::text,
    "timestamp" timestamp with time zone DEFAULT now(),
    completed boolean DEFAULT false,
    CONSTRAINT results_result_type_check CHECK ((result_type = ANY (ARRAY['stdout'::text, 'stderr'::text, 'error'::text, 'complete'::text, 'progress'::text])))
);


ALTER TABLE public.results OWNER TO gla1v3_app;

--
-- Name: TABLE results; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.results IS 'Task execution results and output streams';


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.tasks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    task_type text,
    embedded_type text,
    embedded_params jsonb,
    run_once boolean DEFAULT false,
    command text,
    args jsonb,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT now(),
    sent_at timestamp with time zone,
    executed_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_by uuid,
    CONSTRAINT task_type_check CHECK ((((task_type = 'embedded'::text) AND (embedded_type IS NOT NULL)) OR ((task_type = 'command'::text) AND (command IS NOT NULL)) OR ((task_type IS NULL) AND (command IS NOT NULL)))),
    CONSTRAINT tasks_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'running'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
);


ALTER TABLE public.tasks OWNER TO gla1v3_app;

--
-- Name: TABLE tasks; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.tasks IS 'Commands queued for execution on agents';


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    api_key text,
    description text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tenants OWNER TO gla1v3_app;

--
-- Name: TABLE tenants; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.tenants IS 'Client companies being assessed by red team';


--
-- Name: user_tenants; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.user_tenants (
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    assigned_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_tenants OWNER TO gla1v3_app;

--
-- Name: TABLE user_tenants; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.user_tenants IS 'Maps which users can access which tenant data';


--
-- Name: users; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'operator'::text NOT NULL,
    active boolean DEFAULT true,
    totp_secret text,
    totp_enabled boolean DEFAULT false,
    totp_backup_codes text[],
    totp_enabled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'operator'::text])))
);


ALTER TABLE public.users OWNER TO gla1v3_app;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.users IS 'Red team operators and administrators';


--
-- Name: COLUMN users.totp_secret; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_secret IS 'Encrypted TOTP secret for 2FA';


--
-- Name: COLUMN users.totp_enabled; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_enabled IS 'Whether 2FA is enabled for this user';


--
-- Name: COLUMN users.totp_backup_codes; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_backup_codes IS 'Array of bcrypt-hashed backup codes for account recovery';


--
-- Name: COLUMN users.totp_enabled_at; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_enabled_at IS 'Timestamp when 2FA was enabled';


--
-- Data for Name: agent_blacklist; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.agent_blacklist (agent_id, tenant_id, reason, expires_at, blacklisted_at, revoked) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.agents (id, tenant_id, hostname, cn, os, arch, username, ip_address, latitude, longitude, geo_country, geo_region, geo_city, cert_fingerprint, cert_issued_at, cert_expiry, cert_status, cert_id, status, first_seen, last_seen, created_at, updated_at) FROM stdin;
5f8992da-65f7-485d-b30e-6f2b5404a2d7	00000000-0000-0000-0000-000000000001	Gla1v3-Target-Ubuntu	test	linux	amd64	vagrant	87.52.109.250	55.6802	12.5892	DK	84	Copenhagen	\N	\N	\N	active	test-test-1770938247078	active	2026-02-12 23:17:27.14847+00	2026-02-12 23:33:51.394401+00	2026-02-12 23:17:27.14847+00	2026-02-12 23:33:51.394401+00
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.audit_log (id, tenant_id, user_id, action, resource_type, resource_id, details, ip_address, user_agent, "timestamp") FROM stdin;
\.


--
-- Data for Name: results; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.results (id, tenant_id, agent_id, task_id, stdout, stderr, exit_code, error_message, stream_index, result_type, "timestamp", completed) FROM stdin;
f8e4b1a6-fa60-47fc-a03a-469eb8cb7bed	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	1a5719b6-1f3f-48b4-9fe6-49c4102fa910	[\n  {\n    "pid": "1",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/sbin/init splash"\n  },\n  {\n    "pid": "2",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kthreadd]"\n  },\n  {\n    "pid": "3",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[pool_workqueue_release]"\n  },\n  {\n    "pid": "4",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-rcu_gp]"\n  },\n  {\n    "pid": "5",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-sync_wq]"\n  },\n  {\n    "pid": "6",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kvfree_rcu_reclaim]"\n  },\n  {\n    "pid": "7",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-slub_flushwq]"\n  },\n  {\n    "pid": "8",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-netns]"\n  },\n  {\n    "pid": "13",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-mm_percpu_wq]"\n  },\n  {\n    "pid": "14",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_tasks_kthread]"\n  },\n  {\n    "pid": "15",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_tasks_rude_kthread]"\n  },\n  {\n    "pid": "16",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_tasks_trace_kthread]"\n  },\n  {\n    "pid": "17",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[ksoftirqd/0]"\n  },\n  {\n    "pid": "18",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_preempt]"\n  },\n  {\n    "pid": "19",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_exp_par_gp_kthread_worker/0]"\n  },\n  {\n    "pid": "20",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_exp_gp_kthread_worker]"\n  },\n  {\n    "pid": "21",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[migration/0]"\n  },\n  {\n    "pid": "22",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[idle_inject/0]"\n  },\n  {\n    "pid": "23",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[cpuhp/0]"\n  },\n  {\n    "pid": "24",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kdevtmpfs]"\n  },\n  {\n    "pid": "25",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-inet_frag_wq]"\n  },\n  {\n    "pid": "26",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kauditd]"\n  },\n  {\n    "pid": "27",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[khungtaskd]"\n  },\n  {\n    "pid": "29",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[oom_reaper]"\n  },\n  {\n    "pid": "30",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-writeback]"\n  },\n  {\n    "pid": "31",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kcompactd0]"\n  },\n  {\n    "pid": "32",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[ksmd]"\n  },\n  {\n    "pid": "33",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[khugepaged]"\n  },\n  {\n    "pid": "34",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kintegrityd]"\n  },\n  {\n    "pid": "35",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kblockd]"\n  },\n  {\n    "pid": "36",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-blkcg_punt_bio]"\n  },\n  {\n    "pid": "38",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[irq/9-acpi]"\n  },\n  {\n    "pid": "39",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-tpm_dev_wq]"\n  },\n  {\n    "pid": "40",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ata_sff]"\n  },\n  {\n    "pid": "41",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-md]"\n  },\n  {\n    "pid": "42",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-md_bitmap]"\n  },\n  {\n    "pid": "43",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-edac-poller]"\n  },\n  {\n    "pid": "44",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-devfreq_wq]"\n  },\n  {\n    "pid": "45",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[watchdogd]"\n  },\n  {\n    "pid": "47",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kswapd0]"\n  },\n  {\n    "pid": "48",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[ecryptfs-kthread]"\n  },\n  {\n    "pid": "49",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kthrotld]"\n  },\n  {\n    "pid": "50",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-acpi_thermal_pm]"\n  },\n  {\n    "pid": "51",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[scsi_eh_0]"\n  },\n  {\n    "pid": "52",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-scsi_tmf_0]"\n  },\n  {\n    "pid": "53",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[scsi_eh_1]"\n  },\n  {\n    "pid": "54",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-scsi_tmf_1]"\n  },\n  {\n    "pid": "58",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-mld]"\n  },\n  {\n    "pid": "59",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ipv6_addrconf]"\n  },\n  {\n    "pid": "67",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kstrp]"\n  },\n  {\n    "pid": "69",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u5:0-ttm]"\n  },\n  {\n    "pid": "82",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-charger_manager]"\n  },\n  {\n    "pid": "139",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[scsi_eh_2]"\n  },\n  {\n    "pid": "140",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-scsi_tmf_2]"\n  },\n  {\n    "pid": "181",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[jbd2/sda2-8]"\n  },\n  {\n    "pid": "182",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ext4-rsv-conversion]"\n  },\n  {\n    "pid": "230",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/lib/systemd/systemd-journald"\n  },\n  {\n    "pid": "303",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd-udevd"\n  },\n  {\n    "pid": "351",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[psimon]"\n  },\n  {\n    "pid": "359",\n    "name": "",\n    "user": "systemd+",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/lib/systemd/systemd-oomd"\n  },\n  {\n    "pid": "364",\n    "name": "",\n    "user": "systemd+",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd-resolved"\n  },\n  {\n    "pid": "532",\n    "name": "",\n    "user": "avahi",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "avahi-daemon: running [Gla1v3-Target-Ubuntu.local]"\n  },\n  {\n    "pid": "535",\n    "name": "",\n    "user": "message+",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "@dbus-daemon --system --address=systemd: --nofork --nopidfile --systemd-activation --syslog-only"\n  },\n  {\n    "pid": "540",\n    "name": "",\n    "user": "gnome-r+",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-remote-desktop-daemon --system"\n  },\n  {\n    "pid": "546",\n    "name": "",\n    "user": "polkitd",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/polkit-1/polkitd --no-debug"\n  },\n  {\n    "pid": "547",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/power-profiles-daemon"\n  },\n  {\n    "pid": "549",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-cryptd]"\n  },\n  {\n    "pid": "567",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/lib/snapd/snapd"\n  },\n  {\n    "pid": "578",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/accounts-daemon"\n  },\n  {\n    "pid": "581",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/cron -f -P"\n  },\n  {\n    "pid": "586",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/switcheroo-control"\n  },\n  {\n    "pid": "589",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-iprt-VBoxWQueue]"\n  },\n  {\n    "pid": "591",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd-logind"\n  },\n  {\n    "pid": "595",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/udisks2/udisksd"\n  },\n  {\n    "pid": "624",\n    "name": "",\n    "user": "syslog",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/rsyslogd -n -iNONE"\n  },\n  {\n    "pid": "639",\n    "name": "",\n    "user": "avahi",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "avahi-daemon: chroot helper"\n  },\n  {\n    "pid": "649",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/sbin/NetworkManager --no-daemon"\n  },\n  {\n    "pid": "652",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[irq/18-vmwgfx]"\n  },\n  {\n    "pid": "655",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/wpa_supplicant -u -s -O DIR=/run/wpa_supplicant GROUP=netdev"\n  },\n  {\n    "pid": "674",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ttm]"\n  },\n  {\n    "pid": "684",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/sbin/ModemManager"\n  },\n  {\n    "pid": "1065",\n    "name": "",\n    "user": "root",\n    "cpu": "0.1%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxDRMClient"\n  },\n  {\n    "pid": "1072",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/VBoxService --pidfile /var/run/vboxadd-service.sh"\n  },\n  {\n    "pid": "1209",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/sbin/cupsd -l"\n  },\n  {\n    "pid": "1217",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/bin/python3 /usr/share/unattended-upgrades/unattended-upgrade-shutdown --wait-for-signal"\n  },\n  {\n    "pid": "1256",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/sbin/gdm3"\n  },\n  {\n    "pid": "1291",\n    "name": "",\n    "user": "cups-br+",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/sbin/cups-browsed"\n  },\n  {\n    "pid": "1307",\n    "name": "",\n    "user": "kernoops",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/kerneloops --test"\n  },\n  {\n    "pid": "1319",\n    "name": "",\n    "user": "kernoops",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/kerneloops"\n  },\n  {\n    "pid": "1345",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/var/ossec/bin/wazuh-execd"\n  },\n  {\n    "pid": "1359",\n    "name": "",\n    "user": "wazuh",\n    "cpu": "0.1%",\n    "memory": "0.1%",\n    "command": "/var/ossec/bin/wazuh-agentd"\n  },\n  {\n    "pid": "1383",\n    "name": "",\n    "user": "rtkit",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/rtkit-daemon"\n  },\n  {\n    "pid": "1477",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/var/ossec/bin/wazuh-syscheckd"\n  },\n  {\n    "pid": "1498",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/var/ossec/bin/wazuh-logcollector"\n  },\n  {\n    "pid": "1512",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/var/ossec/bin/wazuh-modulesd"\n  },\n  {\n    "pid": "1545",\n    "name": "",\n    "user": "colord",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/colord"\n  },\n  {\n    "pid": "1593",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/upowerd"\n  },\n  {\n    "pid": "2442",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "gdm-session-worker [pam/gdm-password]"\n  },\n  {\n    "pid": "2816",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd --user"\n  },\n  {\n    "pid": "2817",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "(sd-pam)"\n  },\n  {\n    "pid": "2830",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/pipewire"\n  },\n  {\n    "pid": "2831",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/pipewire -c filter-chain.conf"\n  },\n  {\n    "pid": "2837",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/bin/wireplumber"\n  },\n  {\n    "pid": "2838",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/pipewire-pulse"\n  },\n  {\n    "pid": "2840",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/gnome-keyring-daemon --foreground --components=pkcs11,secrets --control-directory=/run/user/1000/keyring"\n  },\n  {\n    "pid": "2852",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/dbus-daemon --session --address=systemd: --nofork --nopidfile --systemd-activation --syslog-only"\n  },\n  {\n    "pid": "2871",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/xdg-document-portal"\n  },\n  {\n    "pid": "2889",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gdm-wayland-session env GNOME_SHELL_SESSION_MODE=ubuntu /usr/bin/gnome-session --session=ubuntu"\n  },\n  {\n    "pid": "2893",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-session-binary --session=ubuntu"\n  },\n  {\n    "pid": "2944",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/xdg-permission-store"\n  },\n  {\n    "pid": "2955",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "fusermount3 -o rw,nosuid,nodev,fsname=portal,auto_unmount,subtype=portal -- /run/user/1000/doc"\n  },\n  {\n    "pid": "2981",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gcr-ssh-agent --base-dir /run/user/1000/gcr"\n  },\n  {\n    "pid": "2982",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gnome-session-ctl --monitor"\n  },\n  {\n    "pid": "2990",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfsd"\n  },\n  {\n    "pid": "2998",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfsd-fuse /run/user/1000/gvfs -f"\n  },\n  {\n    "pid": "3012",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-session-binary --systemd-service --session=ubuntu"\n  },\n  {\n    "pid": "3053",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.8%",\n    "memory": "5.0%",\n    "command": "/usr/bin/gnome-shell"\n  },\n  {\n    "pid": "3054",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/at-spi-bus-launcher --launch-immediately"\n  },\n  {\n    "pid": "3068",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/dbus-daemon --config-file=/usr/share/defaults/at-spi2/accessibility.conf --nofork --print-address 11 --address=unix:path=/run/user/1000/at-spi/bus"\n  },\n  {\n    "pid": "3117",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/at-spi2-registryd --use-gnome-session"\n  },\n  {\n    "pid": "3135",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-shell-calendar-server"\n  },\n  {\n    "pid": "3154",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/libexec/evolution-source-registry"\n  },\n  {\n    "pid": "3164",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/bin/gjs -m /usr/share/gnome-shell/org.gnome.Shell.Notifications"\n  },\n  {\n    "pid": "3166",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/ibus-daemon --panel disable"\n  },\n  {\n    "pid": "3167",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-a11y-settings"\n  },\n  {\n    "pid": "3168",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gsd-color"\n  },\n  {\n    "pid": "3169",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-datetime"\n  },\n  {\n    "pid": "3170",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-housekeeping"\n  },\n  {\n    "pid": "3171",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gsd-keyboard"\n  },\n  {\n    "pid": "3172",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/gsd-media-keys"\n  },\n  {\n    "pid": "3173",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/gsd-power"\n  },\n  {\n    "pid": "3174",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-print-notifications"\n  },\n  {\n    "pid": "3175",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-rfkill"\n  },\n  {\n    "pid": "3176",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-screensaver-proxy"\n  },\n  {\n    "pid": "3177",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-sharing"\n  },\n  {\n    "pid": "3179",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-smartcard"\n  },\n  {\n    "pid": "3180",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-sound"\n  },\n  {\n    "pid": "3181",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gsd-wacom"\n  },\n  {\n    "pid": "3197",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/goa-daemon"\n  },\n  {\n    "pid": "3203",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.7%",\n    "command": "/usr/libexec/evolution-data-server/evolution-alarm-notify"\n  },\n  {\n    "pid": "3219",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-disk-utility-notify"\n  },\n  {\n    "pid": "3336",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfs-udisks2-volume-monitor"\n  },\n  {\n    "pid": "3358",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/evolution-calendar-factory"\n  },\n  {\n    "pid": "3366",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/ibus-memconf"\n  },\n  {\n    "pid": "3367",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/ibus-extension-gtk3"\n  },\n  {\n    "pid": "3372",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/ibus-portal"\n  },\n  {\n    "pid": "3380",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-printer"\n  },\n  {\n    "pid": "3396",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/evolution-addressbook-factory"\n  },\n  {\n    "pid": "3400",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/goa-identity-service"\n  },\n  {\n    "pid": "3433",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfs-goa-volume-monitor"\n  },\n  {\n    "pid": "3438",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfs-mtp-volume-monitor"\n  },\n  {\n    "pid": "3443",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfs-gphoto2-volume-monitor"\n  },\n  {\n    "pid": "3448",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfs-afc-volume-monitor"\n  },\n  {\n    "pid": "3454",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.8%",\n    "command": "/usr/bin/Xwayland :0 -rootless -noreset -accessx -core -auth /run/user/1000/.mutter-Xwaylandauth.058AK3 -listenfd 4 -listenfd 5 -displayfd 6 -initfd 7 -byteswappedclients"\n  },\n  {\n    "pid": "3474",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/snap/snapd-desktop-integration/343/usr/bin/snapd-desktop-integration"\n  },\n  {\n    "pid": "3479",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/ibus-engine-simple"\n  },\n  {\n    "pid": "3532",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/dconf-service"\n  },\n  {\n    "pid": "3539",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/snap/snapd-desktop-integration/343/usr/bin/snapd-desktop-integration"\n  },\n  {\n    "pid": "3566",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfsd-metadata"\n  },\n  {\n    "pid": "3567",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfsd-trash --spawner :1.20 /org/gtk/gvfs/exec_spaw/0"\n  },\n  {\n    "pid": "3675",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/tracker-miner-fs-3"\n  },\n  {\n    "pid": "3691",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "1.0%",\n    "command": "/usr/libexec/gsd-xsettings"\n  },\n  {\n    "pid": "3694",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/bin/gjs -m /usr/share/gnome-shell/org.gnome.ScreenSaver"\n  },\n  {\n    "pid": "3710",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/xdg-desktop-portal"\n  },\n  {\n    "pid": "3719",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/libexec/xdg-desktop-portal-gnome"\n  },\n  {\n    "pid": "3739",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/xdg-desktop-portal-gtk"\n  },\n  {\n    "pid": "3766",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/ibus-x11"\n  },\n  {\n    "pid": "3768",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "1.2%",\n    "command": "/usr/libexec/mutter-x11-frames"\n  },\n  {\n    "pid": "3773",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxClient --clipboard"\n  },\n  {\n    "pid": "3774",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "2.2%",\n    "command": "/usr/bin/VBoxClient --clipboard"\n  },\n  {\n    "pid": "3801",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxClient --vmsvga-session"\n  },\n  {\n    "pid": "3802",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxClient --vmsvga-session"\n  },\n  {\n    "pid": "3829",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.7%",\n    "command": "/usr/libexec/gnome-terminal-server"\n  },\n  {\n    "pid": "3836",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "bash"\n  },\n  {\n    "pid": "3848",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "bash"\n  },\n  {\n    "pid": "3894",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.4%",\n    "command": "/usr/bin/update-notifier"\n  },\n  {\n    "pid": "4690",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[psimon]"\n  },\n  {\n    "pid": "5256",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/libexec/fwupd/fwupd"\n  },\n  {\n    "pid": "12391",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:4-events_power_efficient]"\n  },\n  {\n    "pid": "13203",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u5:2-ttm]"\n  },\n  {\n    "pid": "13206",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:3-events_unbound]"\n  },\n  {\n    "pid": "13646",\n    "name": "",\n    "user": "root",\n    "cpu": "0.2%",\n    "memory": "0.0%",\n    "command": "[kworker/0:0-events]"\n  },\n  {\n    "pid": "13848",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:2-events_power_efficient]"\n  },\n  {\n    "pid": "13934",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:1H-kblockd]"\n  },\n  {\n    "pid": "14047",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:2-cgroup_destroy]"\n  },\n  {\n    "pid": "14094",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:1-events_power_efficient]"\n  },\n  {\n    "pid": "14143",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:2H]"\n  },\n  {\n    "pid": "14210",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.3%",\n    "memory": "0.7%",\n    "command": "gjs /usr/share/gnome-shell/extensions/ding@rastersoft.com/app/ding.js -E -P /usr/share/gnome-shell/extensions/ding@rastersoft.com/app"\n  },\n  {\n    "pid": "14259",\n    "name": "",\n    "user": "root",\n    "cpu": "0.1%",\n    "memory": "0.0%",\n    "command": "[kworker/0:0H-kblockd]"\n  },\n  {\n    "pid": "14263",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:1-cgroup_destroy]"\n  },\n  {\n    "pid": "14275",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.2%",\n    "memory": "0.1%",\n    "command": "./gla1v3-agent-linux"\n  },\n  {\n    "pid": "14302",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "100%",\n    "memory": "0.0%",\n    "command": "ps aux"\n  }\n]	\N	\N	\N	0	complete	2026-02-12 23:17:47.554455+00	t
24f235fa-28e4-4393-b086-2851fc35e1b5	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	664116a8-b488-4488-ba77-46621de9906f	[\n  {\n    "pid": "1",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/sbin/init splash"\n  },\n  {\n    "pid": "2",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kthreadd]"\n  },\n  {\n    "pid": "3",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[pool_workqueue_release]"\n  },\n  {\n    "pid": "4",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-rcu_gp]"\n  },\n  {\n    "pid": "5",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-sync_wq]"\n  },\n  {\n    "pid": "6",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kvfree_rcu_reclaim]"\n  },\n  {\n    "pid": "7",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-slub_flushwq]"\n  },\n  {\n    "pid": "8",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-netns]"\n  },\n  {\n    "pid": "13",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-mm_percpu_wq]"\n  },\n  {\n    "pid": "14",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_tasks_kthread]"\n  },\n  {\n    "pid": "15",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_tasks_rude_kthread]"\n  },\n  {\n    "pid": "16",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_tasks_trace_kthread]"\n  },\n  {\n    "pid": "17",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[ksoftirqd/0]"\n  },\n  {\n    "pid": "18",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_preempt]"\n  },\n  {\n    "pid": "19",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_exp_par_gp_kthread_worker/0]"\n  },\n  {\n    "pid": "20",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_exp_gp_kthread_worker]"\n  },\n  {\n    "pid": "21",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[migration/0]"\n  },\n  {\n    "pid": "22",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[idle_inject/0]"\n  },\n  {\n    "pid": "23",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[cpuhp/0]"\n  },\n  {\n    "pid": "24",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kdevtmpfs]"\n  },\n  {\n    "pid": "25",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-inet_frag_wq]"\n  },\n  {\n    "pid": "26",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kauditd]"\n  },\n  {\n    "pid": "27",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[khungtaskd]"\n  },\n  {\n    "pid": "29",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[oom_reaper]"\n  },\n  {\n    "pid": "30",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-writeback]"\n  },\n  {\n    "pid": "31",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kcompactd0]"\n  },\n  {\n    "pid": "32",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[ksmd]"\n  },\n  {\n    "pid": "33",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[khugepaged]"\n  },\n  {\n    "pid": "34",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kintegrityd]"\n  },\n  {\n    "pid": "35",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kblockd]"\n  },\n  {\n    "pid": "36",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-blkcg_punt_bio]"\n  },\n  {\n    "pid": "38",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[irq/9-acpi]"\n  },\n  {\n    "pid": "39",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-tpm_dev_wq]"\n  },\n  {\n    "pid": "40",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ata_sff]"\n  },\n  {\n    "pid": "41",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-md]"\n  },\n  {\n    "pid": "42",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-md_bitmap]"\n  },\n  {\n    "pid": "43",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-edac-poller]"\n  },\n  {\n    "pid": "44",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-devfreq_wq]"\n  },\n  {\n    "pid": "45",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[watchdogd]"\n  },\n  {\n    "pid": "47",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kswapd0]"\n  },\n  {\n    "pid": "48",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[ecryptfs-kthread]"\n  },\n  {\n    "pid": "49",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kthrotld]"\n  },\n  {\n    "pid": "50",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-acpi_thermal_pm]"\n  },\n  {\n    "pid": "51",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[scsi_eh_0]"\n  },\n  {\n    "pid": "52",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-scsi_tmf_0]"\n  },\n  {\n    "pid": "53",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[scsi_eh_1]"\n  },\n  {\n    "pid": "54",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-scsi_tmf_1]"\n  },\n  {\n    "pid": "58",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-mld]"\n  },\n  {\n    "pid": "59",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ipv6_addrconf]"\n  },\n  {\n    "pid": "67",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kstrp]"\n  },\n  {\n    "pid": "69",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u5:0-ttm]"\n  },\n  {\n    "pid": "82",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-charger_manager]"\n  },\n  {\n    "pid": "139",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[scsi_eh_2]"\n  },\n  {\n    "pid": "140",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-scsi_tmf_2]"\n  },\n  {\n    "pid": "181",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[jbd2/sda2-8]"\n  },\n  {\n    "pid": "182",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ext4-rsv-conversion]"\n  },\n  {\n    "pid": "230",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/lib/systemd/systemd-journald"\n  },\n  {\n    "pid": "303",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd-udevd"\n  },\n  {\n    "pid": "351",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[psimon]"\n  },\n  {\n    "pid": "359",\n    "name": "",\n    "user": "systemd+",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/lib/systemd/systemd-oomd"\n  },\n  {\n    "pid": "364",\n    "name": "",\n    "user": "systemd+",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd-resolved"\n  },\n  {\n    "pid": "532",\n    "name": "",\n    "user": "avahi",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "avahi-daemon: running [Gla1v3-Target-Ubuntu.local]"\n  },\n  {\n    "pid": "535",\n    "name": "",\n    "user": "message+",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "@dbus-daemon --system --address=systemd: --nofork --nopidfile --systemd-activation --syslog-only"\n  },\n  {\n    "pid": "540",\n    "name": "",\n    "user": "gnome-r+",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-remote-desktop-daemon --system"\n  },\n  {\n    "pid": "546",\n    "name": "",\n    "user": "polkitd",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/polkit-1/polkitd --no-debug"\n  },\n  {\n    "pid": "547",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/power-profiles-daemon"\n  },\n  {\n    "pid": "549",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-cryptd]"\n  },\n  {\n    "pid": "567",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/lib/snapd/snapd"\n  },\n  {\n    "pid": "578",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/accounts-daemon"\n  },\n  {\n    "pid": "581",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/cron -f -P"\n  },\n  {\n    "pid": "586",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/switcheroo-control"\n  },\n  {\n    "pid": "589",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-iprt-VBoxWQueue]"\n  },\n  {\n    "pid": "591",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd-logind"\n  },\n  {\n    "pid": "595",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/udisks2/udisksd"\n  },\n  {\n    "pid": "624",\n    "name": "",\n    "user": "syslog",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/rsyslogd -n -iNONE"\n  },\n  {\n    "pid": "639",\n    "name": "",\n    "user": "avahi",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "avahi-daemon: chroot helper"\n  },\n  {\n    "pid": "649",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/sbin/NetworkManager --no-daemon"\n  },\n  {\n    "pid": "652",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[irq/18-vmwgfx]"\n  },\n  {\n    "pid": "655",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/wpa_supplicant -u -s -O DIR=/run/wpa_supplicant GROUP=netdev"\n  },\n  {\n    "pid": "674",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ttm]"\n  },\n  {\n    "pid": "684",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/sbin/ModemManager"\n  },\n  {\n    "pid": "1065",\n    "name": "",\n    "user": "root",\n    "cpu": "0.1%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxDRMClient"\n  },\n  {\n    "pid": "1072",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/VBoxService --pidfile /var/run/vboxadd-service.sh"\n  },\n  {\n    "pid": "1209",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/sbin/cupsd -l"\n  },\n  {\n    "pid": "1217",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/bin/python3 /usr/share/unattended-upgrades/unattended-upgrade-shutdown --wait-for-signal"\n  },\n  {\n    "pid": "1256",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/sbin/gdm3"\n  },\n  {\n    "pid": "1291",\n    "name": "",\n    "user": "cups-br+",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/sbin/cups-browsed"\n  },\n  {\n    "pid": "1307",\n    "name": "",\n    "user": "kernoops",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/kerneloops --test"\n  },\n  {\n    "pid": "1319",\n    "name": "",\n    "user": "kernoops",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/kerneloops"\n  },\n  {\n    "pid": "1345",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/var/ossec/bin/wazuh-execd"\n  },\n  {\n    "pid": "1359",\n    "name": "",\n    "user": "wazuh",\n    "cpu": "0.1%",\n    "memory": "0.1%",\n    "command": "/var/ossec/bin/wazuh-agentd"\n  },\n  {\n    "pid": "1383",\n    "name": "",\n    "user": "rtkit",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/rtkit-daemon"\n  },\n  {\n    "pid": "1477",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/var/ossec/bin/wazuh-syscheckd"\n  },\n  {\n    "pid": "1498",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/var/ossec/bin/wazuh-logcollector"\n  },\n  {\n    "pid": "1512",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/var/ossec/bin/wazuh-modulesd"\n  },\n  {\n    "pid": "1545",\n    "name": "",\n    "user": "colord",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/colord"\n  },\n  {\n    "pid": "1593",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/upowerd"\n  },\n  {\n    "pid": "2442",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "gdm-session-worker [pam/gdm-password]"\n  },\n  {\n    "pid": "2816",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd --user"\n  },\n  {\n    "pid": "2817",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "(sd-pam)"\n  },\n  {\n    "pid": "2830",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/pipewire"\n  },\n  {\n    "pid": "2831",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/pipewire -c filter-chain.conf"\n  },\n  {\n    "pid": "2837",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/bin/wireplumber"\n  },\n  {\n    "pid": "2838",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/pipewire-pulse"\n  },\n  {\n    "pid": "2840",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/gnome-keyring-daemon --foreground --components=pkcs11,secrets --control-directory=/run/user/1000/keyring"\n  },\n  {\n    "pid": "2852",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/dbus-daemon --session --address=systemd: --nofork --nopidfile --systemd-activation --syslog-only"\n  },\n  {\n    "pid": "2871",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/xdg-document-portal"\n  },\n  {\n    "pid": "2889",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gdm-wayland-session env GNOME_SHELL_SESSION_MODE=ubuntu /usr/bin/gnome-session --session=ubuntu"\n  },\n  {\n    "pid": "2893",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-session-binary --session=ubuntu"\n  },\n  {\n    "pid": "2944",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/xdg-permission-store"\n  },\n  {\n    "pid": "2955",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "fusermount3 -o rw,nosuid,nodev,fsname=portal,auto_unmount,subtype=portal -- /run/user/1000/doc"\n  },\n  {\n    "pid": "2981",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gcr-ssh-agent --base-dir /run/user/1000/gcr"\n  },\n  {\n    "pid": "2982",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gnome-session-ctl --monitor"\n  },\n  {\n    "pid": "2990",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfsd"\n  },\n  {\n    "pid": "2998",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfsd-fuse /run/user/1000/gvfs -f"\n  },\n  {\n    "pid": "3012",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-session-binary --systemd-service --session=ubuntu"\n  },\n  {\n    "pid": "3053",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.8%",\n    "memory": "5.0%",\n    "command": "/usr/bin/gnome-shell"\n  },\n  {\n    "pid": "3054",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/at-spi-bus-launcher --launch-immediately"\n  },\n  {\n    "pid": "3068",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/dbus-daemon --config-file=/usr/share/defaults/at-spi2/accessibility.conf --nofork --print-address 11 --address=unix:path=/run/user/1000/at-spi/bus"\n  },\n  {\n    "pid": "3117",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/at-spi2-registryd --use-gnome-session"\n  },\n  {\n    "pid": "3135",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-shell-calendar-server"\n  },\n  {\n    "pid": "3154",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/libexec/evolution-source-registry"\n  },\n  {\n    "pid": "3164",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/bin/gjs -m /usr/share/gnome-shell/org.gnome.Shell.Notifications"\n  },\n  {\n    "pid": "3166",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/ibus-daemon --panel disable"\n  },\n  {\n    "pid": "3167",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-a11y-settings"\n  },\n  {\n    "pid": "3168",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gsd-color"\n  },\n  {\n    "pid": "3169",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-datetime"\n  },\n  {\n    "pid": "3170",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-housekeeping"\n  },\n  {\n    "pid": "3171",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gsd-keyboard"\n  },\n  {\n    "pid": "3172",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/gsd-media-keys"\n  },\n  {\n    "pid": "3173",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/gsd-power"\n  },\n  {\n    "pid": "3174",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-print-notifications"\n  },\n  {\n    "pid": "3175",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-rfkill"\n  },\n  {\n    "pid": "3176",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-screensaver-proxy"\n  },\n  {\n    "pid": "3177",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-sharing"\n  },\n  {\n    "pid": "3179",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-smartcard"\n  },\n  {\n    "pid": "3180",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-sound"\n  },\n  {\n    "pid": "3181",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gsd-wacom"\n  },\n  {\n    "pid": "3197",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/goa-daemon"\n  },\n  {\n    "pid": "3203",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.7%",\n    "command": "/usr/libexec/evolution-data-server/evolution-alarm-notify"\n  },\n  {\n    "pid": "3219",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-disk-utility-notify"\n  },\n  {\n    "pid": "3336",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfs-udisks2-volume-monitor"\n  },\n  {\n    "pid": "3358",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/evolution-calendar-factory"\n  },\n  {\n    "pid": "3366",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/ibus-memconf"\n  },\n  {\n    "pid": "3367",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/ibus-extension-gtk3"\n  },\n  {\n    "pid": "3372",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/ibus-portal"\n  },\n  {\n    "pid": "3380",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-printer"\n  },\n  {\n    "pid": "3396",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/evolution-addressbook-factory"\n  },\n  {\n    "pid": "3400",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/goa-identity-service"\n  },\n  {\n    "pid": "3433",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfs-goa-volume-monitor"\n  },\n  {\n    "pid": "3438",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfs-mtp-volume-monitor"\n  },\n  {\n    "pid": "3443",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfs-gphoto2-volume-monitor"\n  },\n  {\n    "pid": "3448",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfs-afc-volume-monitor"\n  },\n  {\n    "pid": "3454",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.8%",\n    "command": "/usr/bin/Xwayland :0 -rootless -noreset -accessx -core -auth /run/user/1000/.mutter-Xwaylandauth.058AK3 -listenfd 4 -listenfd 5 -displayfd 6 -initfd 7 -byteswappedclients"\n  },\n  {\n    "pid": "3474",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/snap/snapd-desktop-integration/343/usr/bin/snapd-desktop-integration"\n  },\n  {\n    "pid": "3479",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/ibus-engine-simple"\n  },\n  {\n    "pid": "3532",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/dconf-service"\n  },\n  {\n    "pid": "3539",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/snap/snapd-desktop-integration/343/usr/bin/snapd-desktop-integration"\n  },\n  {\n    "pid": "3566",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfsd-metadata"\n  },\n  {\n    "pid": "3567",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfsd-trash --spawner :1.20 /org/gtk/gvfs/exec_spaw/0"\n  },\n  {\n    "pid": "3675",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/tracker-miner-fs-3"\n  },\n  {\n    "pid": "3691",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "1.0%",\n    "command": "/usr/libexec/gsd-xsettings"\n  },\n  {\n    "pid": "3694",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/bin/gjs -m /usr/share/gnome-shell/org.gnome.ScreenSaver"\n  },\n  {\n    "pid": "3710",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/xdg-desktop-portal"\n  },\n  {\n    "pid": "3719",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/libexec/xdg-desktop-portal-gnome"\n  },\n  {\n    "pid": "3739",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/xdg-desktop-portal-gtk"\n  },\n  {\n    "pid": "3766",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/ibus-x11"\n  },\n  {\n    "pid": "3768",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "1.2%",\n    "command": "/usr/libexec/mutter-x11-frames"\n  },\n  {\n    "pid": "3773",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxClient --clipboard"\n  },\n  {\n    "pid": "3774",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "2.2%",\n    "command": "/usr/bin/VBoxClient --clipboard"\n  },\n  {\n    "pid": "3801",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxClient --vmsvga-session"\n  },\n  {\n    "pid": "3802",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxClient --vmsvga-session"\n  },\n  {\n    "pid": "3829",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.7%",\n    "command": "/usr/libexec/gnome-terminal-server"\n  },\n  {\n    "pid": "3836",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "bash"\n  },\n  {\n    "pid": "3848",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "bash"\n  },\n  {\n    "pid": "3894",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.4%",\n    "command": "/usr/bin/update-notifier"\n  },\n  {\n    "pid": "4690",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[psimon]"\n  },\n  {\n    "pid": "5256",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/libexec/fwupd/fwupd"\n  },\n  {\n    "pid": "12391",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:4-events_power_efficient]"\n  },\n  {\n    "pid": "13203",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u5:2-ttm]"\n  },\n  {\n    "pid": "13206",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:3-events_power_efficient]"\n  },\n  {\n    "pid": "13646",\n    "name": "",\n    "user": "root",\n    "cpu": "0.2%",\n    "memory": "0.0%",\n    "command": "[kworker/0:0-events]"\n  },\n  {\n    "pid": "13848",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:2-events_unbound]"\n  },\n  {\n    "pid": "13934",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:1H-kblockd]"\n  },\n  {\n    "pid": "14094",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:1-events_power_efficient]"\n  },\n  {\n    "pid": "14210",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.7%",\n    "command": "gjs /usr/share/gnome-shell/extensions/ding@rastersoft.com/app/ding.js -E -P /usr/share/gnome-shell/extensions/ding@rastersoft.com/app"\n  },\n  {\n    "pid": "14259",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:0H-kblockd]"\n  },\n  {\n    "pid": "14263",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:1-cgroup_destroy]"\n  },\n  {\n    "pid": "14330",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "14.2%",\n    "memory": "0.0%",\n    "command": "./gla1v3-agent-linux"\n  },\n  {\n    "pid": "14343",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "ps aux"\n  }\n]	\N	\N	\N	0	complete	2026-02-12 23:22:52.678071+00	t
83e319cb-904d-491c-b646-cf410314191c	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	b9f62e0a-6ddf-471c-a632-7ae5414db243	{\n  "arch": "amd64",\n  "hostname": "Gla1v3-Target-Ubuntu",\n  "kernel": "6.14.0-37-generic",\n  "os": "linux",\n  "os_version": "Ubuntu 24.04.3 LTS"\n}	\N	\N	\N	0	complete	2026-02-12 23:22:52.687073+00	t
7f915a91-7562-4ef6-821e-f197f70d9293	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	6b2ccfe8-c367-43d9-a354-8c6aefadf0bb	{\n  "has_sudo": true,\n  "is_root": false,\n  "uid": "1000"\n}	\N	\N	\N	0	complete	2026-02-12 23:22:52.693763+00	t
8a7294b2-8ab0-4a33-8fb1-7867e77632fc	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	fa923445-2a0a-4fd3-848c-768abebe09c0	[\n  {\n    "pid": "1",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/sbin/init splash"\n  },\n  {\n    "pid": "2",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kthreadd]"\n  },\n  {\n    "pid": "3",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[pool_workqueue_release]"\n  },\n  {\n    "pid": "4",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-rcu_gp]"\n  },\n  {\n    "pid": "5",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-sync_wq]"\n  },\n  {\n    "pid": "6",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kvfree_rcu_reclaim]"\n  },\n  {\n    "pid": "7",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-slub_flushwq]"\n  },\n  {\n    "pid": "8",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-netns]"\n  },\n  {\n    "pid": "13",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-mm_percpu_wq]"\n  },\n  {\n    "pid": "14",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_tasks_kthread]"\n  },\n  {\n    "pid": "15",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_tasks_rude_kthread]"\n  },\n  {\n    "pid": "16",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_tasks_trace_kthread]"\n  },\n  {\n    "pid": "17",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[ksoftirqd/0]"\n  },\n  {\n    "pid": "18",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_preempt]"\n  },\n  {\n    "pid": "19",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_exp_par_gp_kthread_worker/0]"\n  },\n  {\n    "pid": "20",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[rcu_exp_gp_kthread_worker]"\n  },\n  {\n    "pid": "21",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[migration/0]"\n  },\n  {\n    "pid": "22",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[idle_inject/0]"\n  },\n  {\n    "pid": "23",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[cpuhp/0]"\n  },\n  {\n    "pid": "24",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kdevtmpfs]"\n  },\n  {\n    "pid": "25",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-inet_frag_wq]"\n  },\n  {\n    "pid": "26",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kauditd]"\n  },\n  {\n    "pid": "27",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[khungtaskd]"\n  },\n  {\n    "pid": "29",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[oom_reaper]"\n  },\n  {\n    "pid": "30",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-writeback]"\n  },\n  {\n    "pid": "31",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kcompactd0]"\n  },\n  {\n    "pid": "32",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[ksmd]"\n  },\n  {\n    "pid": "33",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[khugepaged]"\n  },\n  {\n    "pid": "34",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kintegrityd]"\n  },\n  {\n    "pid": "35",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kblockd]"\n  },\n  {\n    "pid": "36",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-blkcg_punt_bio]"\n  },\n  {\n    "pid": "38",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[irq/9-acpi]"\n  },\n  {\n    "pid": "39",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-tpm_dev_wq]"\n  },\n  {\n    "pid": "40",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ata_sff]"\n  },\n  {\n    "pid": "41",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-md]"\n  },\n  {\n    "pid": "42",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-md_bitmap]"\n  },\n  {\n    "pid": "43",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-edac-poller]"\n  },\n  {\n    "pid": "44",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-devfreq_wq]"\n  },\n  {\n    "pid": "45",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[watchdogd]"\n  },\n  {\n    "pid": "47",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kswapd0]"\n  },\n  {\n    "pid": "48",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[ecryptfs-kthread]"\n  },\n  {\n    "pid": "49",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kthrotld]"\n  },\n  {\n    "pid": "50",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-acpi_thermal_pm]"\n  },\n  {\n    "pid": "51",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[scsi_eh_0]"\n  },\n  {\n    "pid": "52",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-scsi_tmf_0]"\n  },\n  {\n    "pid": "53",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[scsi_eh_1]"\n  },\n  {\n    "pid": "54",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-scsi_tmf_1]"\n  },\n  {\n    "pid": "58",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-mld]"\n  },\n  {\n    "pid": "59",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ipv6_addrconf]"\n  },\n  {\n    "pid": "67",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-kstrp]"\n  },\n  {\n    "pid": "69",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u5:0-ttm]"\n  },\n  {\n    "pid": "82",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-charger_manager]"\n  },\n  {\n    "pid": "139",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[scsi_eh_2]"\n  },\n  {\n    "pid": "140",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-scsi_tmf_2]"\n  },\n  {\n    "pid": "181",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[jbd2/sda2-8]"\n  },\n  {\n    "pid": "182",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ext4-rsv-conversion]"\n  },\n  {\n    "pid": "230",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/lib/systemd/systemd-journald"\n  },\n  {\n    "pid": "303",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd-udevd"\n  },\n  {\n    "pid": "351",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[psimon]"\n  },\n  {\n    "pid": "359",\n    "name": "",\n    "user": "systemd+",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/lib/systemd/systemd-oomd"\n  },\n  {\n    "pid": "364",\n    "name": "",\n    "user": "systemd+",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd-resolved"\n  },\n  {\n    "pid": "532",\n    "name": "",\n    "user": "avahi",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "avahi-daemon: running [Gla1v3-Target-Ubuntu.local]"\n  },\n  {\n    "pid": "535",\n    "name": "",\n    "user": "message+",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "@dbus-daemon --system --address=systemd: --nofork --nopidfile --systemd-activation --syslog-only"\n  },\n  {\n    "pid": "540",\n    "name": "",\n    "user": "gnome-r+",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-remote-desktop-daemon --system"\n  },\n  {\n    "pid": "546",\n    "name": "",\n    "user": "polkitd",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/polkit-1/polkitd --no-debug"\n  },\n  {\n    "pid": "547",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/power-profiles-daemon"\n  },\n  {\n    "pid": "549",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-cryptd]"\n  },\n  {\n    "pid": "567",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/lib/snapd/snapd"\n  },\n  {\n    "pid": "578",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/accounts-daemon"\n  },\n  {\n    "pid": "581",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/cron -f -P"\n  },\n  {\n    "pid": "586",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/switcheroo-control"\n  },\n  {\n    "pid": "589",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-iprt-VBoxWQueue]"\n  },\n  {\n    "pid": "591",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd-logind"\n  },\n  {\n    "pid": "595",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/udisks2/udisksd"\n  },\n  {\n    "pid": "624",\n    "name": "",\n    "user": "syslog",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/rsyslogd -n -iNONE"\n  },\n  {\n    "pid": "639",\n    "name": "",\n    "user": "avahi",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "avahi-daemon: chroot helper"\n  },\n  {\n    "pid": "649",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/sbin/NetworkManager --no-daemon"\n  },\n  {\n    "pid": "652",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[irq/18-vmwgfx]"\n  },\n  {\n    "pid": "655",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/wpa_supplicant -u -s -O DIR=/run/wpa_supplicant GROUP=netdev"\n  },\n  {\n    "pid": "674",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/R-ttm]"\n  },\n  {\n    "pid": "684",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/sbin/ModemManager"\n  },\n  {\n    "pid": "1065",\n    "name": "",\n    "user": "root",\n    "cpu": "0.1%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxDRMClient"\n  },\n  {\n    "pid": "1072",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/VBoxService --pidfile /var/run/vboxadd-service.sh"\n  },\n  {\n    "pid": "1209",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/sbin/cupsd -l"\n  },\n  {\n    "pid": "1217",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/bin/python3 /usr/share/unattended-upgrades/unattended-upgrade-shutdown --wait-for-signal"\n  },\n  {\n    "pid": "1256",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/sbin/gdm3"\n  },\n  {\n    "pid": "1291",\n    "name": "",\n    "user": "cups-br+",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/sbin/cups-browsed"\n  },\n  {\n    "pid": "1307",\n    "name": "",\n    "user": "kernoops",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/kerneloops --test"\n  },\n  {\n    "pid": "1319",\n    "name": "",\n    "user": "kernoops",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/sbin/kerneloops"\n  },\n  {\n    "pid": "1345",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/var/ossec/bin/wazuh-execd"\n  },\n  {\n    "pid": "1359",\n    "name": "",\n    "user": "wazuh",\n    "cpu": "0.1%",\n    "memory": "0.1%",\n    "command": "/var/ossec/bin/wazuh-agentd"\n  },\n  {\n    "pid": "1383",\n    "name": "",\n    "user": "rtkit",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/rtkit-daemon"\n  },\n  {\n    "pid": "1477",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/var/ossec/bin/wazuh-syscheckd"\n  },\n  {\n    "pid": "1498",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/var/ossec/bin/wazuh-logcollector"\n  },\n  {\n    "pid": "1512",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/var/ossec/bin/wazuh-modulesd"\n  },\n  {\n    "pid": "1545",\n    "name": "",\n    "user": "colord",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/colord"\n  },\n  {\n    "pid": "1593",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/upowerd"\n  },\n  {\n    "pid": "2442",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "gdm-session-worker [pam/gdm-password]"\n  },\n  {\n    "pid": "2816",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/lib/systemd/systemd --user"\n  },\n  {\n    "pid": "2817",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "(sd-pam)"\n  },\n  {\n    "pid": "2830",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/pipewire"\n  },\n  {\n    "pid": "2831",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/pipewire -c filter-chain.conf"\n  },\n  {\n    "pid": "2837",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/bin/wireplumber"\n  },\n  {\n    "pid": "2838",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/pipewire-pulse"\n  },\n  {\n    "pid": "2840",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/gnome-keyring-daemon --foreground --components=pkcs11,secrets --control-directory=/run/user/1000/keyring"\n  },\n  {\n    "pid": "2852",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/dbus-daemon --session --address=systemd: --nofork --nopidfile --systemd-activation --syslog-only"\n  },\n  {\n    "pid": "2871",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/xdg-document-portal"\n  },\n  {\n    "pid": "2889",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gdm-wayland-session env GNOME_SHELL_SESSION_MODE=ubuntu /usr/bin/gnome-session --session=ubuntu"\n  },\n  {\n    "pid": "2893",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-session-binary --session=ubuntu"\n  },\n  {\n    "pid": "2944",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/xdg-permission-store"\n  },\n  {\n    "pid": "2955",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "fusermount3 -o rw,nosuid,nodev,fsname=portal,auto_unmount,subtype=portal -- /run/user/1000/doc"\n  },\n  {\n    "pid": "2981",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gcr-ssh-agent --base-dir /run/user/1000/gcr"\n  },\n  {\n    "pid": "2982",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gnome-session-ctl --monitor"\n  },\n  {\n    "pid": "2990",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfsd"\n  },\n  {\n    "pid": "2998",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfsd-fuse /run/user/1000/gvfs -f"\n  },\n  {\n    "pid": "3012",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-session-binary --systemd-service --session=ubuntu"\n  },\n  {\n    "pid": "3053",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.8%",\n    "memory": "5.1%",\n    "command": "/usr/bin/gnome-shell"\n  },\n  {\n    "pid": "3054",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/at-spi-bus-launcher --launch-immediately"\n  },\n  {\n    "pid": "3068",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/dbus-daemon --config-file=/usr/share/defaults/at-spi2/accessibility.conf --nofork --print-address 11 --address=unix:path=/run/user/1000/at-spi/bus"\n  },\n  {\n    "pid": "3117",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/at-spi2-registryd --use-gnome-session"\n  },\n  {\n    "pid": "3135",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gnome-shell-calendar-server"\n  },\n  {\n    "pid": "3154",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/libexec/evolution-source-registry"\n  },\n  {\n    "pid": "3164",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/bin/gjs -m /usr/share/gnome-shell/org.gnome.Shell.Notifications"\n  },\n  {\n    "pid": "3166",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/bin/ibus-daemon --panel disable"\n  },\n  {\n    "pid": "3167",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-a11y-settings"\n  },\n  {\n    "pid": "3168",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gsd-color"\n  },\n  {\n    "pid": "3169",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-datetime"\n  },\n  {\n    "pid": "3170",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-housekeeping"\n  },\n  {\n    "pid": "3171",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gsd-keyboard"\n  },\n  {\n    "pid": "3172",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/gsd-media-keys"\n  },\n  {\n    "pid": "3173",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/gsd-power"\n  },\n  {\n    "pid": "3174",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-print-notifications"\n  },\n  {\n    "pid": "3175",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-rfkill"\n  },\n  {\n    "pid": "3176",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-screensaver-proxy"\n  },\n  {\n    "pid": "3177",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-sharing"\n  },\n  {\n    "pid": "3179",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-smartcard"\n  },\n  {\n    "pid": "3180",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-sound"\n  },\n  {\n    "pid": "3181",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/gsd-wacom"\n  },\n  {\n    "pid": "3197",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.2%",\n    "command": "/usr/libexec/goa-daemon"\n  },\n  {\n    "pid": "3203",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.7%",\n    "command": "/usr/libexec/evolution-data-server/evolution-alarm-notify"\n  },\n  {\n    "pid": "3219",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gsd-disk-utility-notify"\n  },\n  {\n    "pid": "3336",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfs-udisks2-volume-monitor"\n  },\n  {\n    "pid": "3358",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/evolution-calendar-factory"\n  },\n  {\n    "pid": "3366",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/ibus-memconf"\n  },\n  {\n    "pid": "3367",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/ibus-extension-gtk3"\n  },\n  {\n    "pid": "3372",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/ibus-portal"\n  },\n  {\n    "pid": "3380",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gsd-printer"\n  },\n  {\n    "pid": "3396",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/evolution-addressbook-factory"\n  },\n  {\n    "pid": "3400",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/goa-identity-service"\n  },\n  {\n    "pid": "3433",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfs-goa-volume-monitor"\n  },\n  {\n    "pid": "3438",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfs-mtp-volume-monitor"\n  },\n  {\n    "pid": "3443",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfs-gphoto2-volume-monitor"\n  },\n  {\n    "pid": "3448",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfs-afc-volume-monitor"\n  },\n  {\n    "pid": "3454",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.8%",\n    "command": "/usr/bin/Xwayland :0 -rootless -noreset -accessx -core -auth /run/user/1000/.mutter-Xwaylandauth.058AK3 -listenfd 4 -listenfd 5 -displayfd 6 -initfd 7 -byteswappedclients"\n  },\n  {\n    "pid": "3474",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/snap/snapd-desktop-integration/343/usr/bin/snapd-desktop-integration"\n  },\n  {\n    "pid": "3479",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/ibus-engine-simple"\n  },\n  {\n    "pid": "3532",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/dconf-service"\n  },\n  {\n    "pid": "3539",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/snap/snapd-desktop-integration/343/usr/bin/snapd-desktop-integration"\n  },\n  {\n    "pid": "3566",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/libexec/gvfsd-metadata"\n  },\n  {\n    "pid": "3567",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/gvfsd-trash --spawner :1.20 /org/gtk/gvfs/exec_spaw/0"\n  },\n  {\n    "pid": "3675",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/tracker-miner-fs-3"\n  },\n  {\n    "pid": "3691",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "1.0%",\n    "command": "/usr/libexec/gsd-xsettings"\n  },\n  {\n    "pid": "3694",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/bin/gjs -m /usr/share/gnome-shell/org.gnome.ScreenSaver"\n  },\n  {\n    "pid": "3710",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/xdg-desktop-portal"\n  },\n  {\n    "pid": "3719",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/libexec/xdg-desktop-portal-gnome"\n  },\n  {\n    "pid": "3739",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/xdg-desktop-portal-gtk"\n  },\n  {\n    "pid": "3766",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.3%",\n    "command": "/usr/libexec/ibus-x11"\n  },\n  {\n    "pid": "3768",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "1.2%",\n    "command": "/usr/libexec/mutter-x11-frames"\n  },\n  {\n    "pid": "3773",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxClient --clipboard"\n  },\n  {\n    "pid": "3774",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "2.5%",\n    "command": "/usr/bin/VBoxClient --clipboard"\n  },\n  {\n    "pid": "3801",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxClient --vmsvga-session"\n  },\n  {\n    "pid": "3802",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "/usr/bin/VBoxClient --vmsvga-session"\n  },\n  {\n    "pid": "3829",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.7%",\n    "command": "/usr/libexec/gnome-terminal-server"\n  },\n  {\n    "pid": "3836",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "bash"\n  },\n  {\n    "pid": "3848",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "bash"\n  },\n  {\n    "pid": "3894",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.4%",\n    "command": "/usr/bin/update-notifier"\n  },\n  {\n    "pid": "4690",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[psimon]"\n  },\n  {\n    "pid": "5256",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.5%",\n    "command": "/usr/libexec/fwupd/fwupd"\n  },\n  {\n    "pid": "12391",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:4-events_unbound]"\n  },\n  {\n    "pid": "13203",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u5:2-ttm]"\n  },\n  {\n    "pid": "13206",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:3-kvfree_rcu_reclaim]"\n  },\n  {\n    "pid": "13646",\n    "name": "",\n    "user": "root",\n    "cpu": "0.2%",\n    "memory": "0.0%",\n    "command": "[kworker/0:0-events]"\n  },\n  {\n    "pid": "13848",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:2-events_unbound]"\n  },\n  {\n    "pid": "13934",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:1H-kblockd]"\n  },\n  {\n    "pid": "14094",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/u4:1-events_power_efficient]"\n  },\n  {\n    "pid": "14259",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:0H-kblockd]"\n  },\n  {\n    "pid": "14363",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:2-cgroup_destroy]"\n  },\n  {\n    "pid": "14396",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:2H-kblockd]"\n  },\n  {\n    "pid": "14401",\n    "name": "",\n    "user": "root",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "[kworker/0:1]"\n  },\n  {\n    "pid": "14412",\n    "name": "",\n    "user": "root",\n    "cpu": "0.7%",\n    "memory": "0.1%",\n    "command": "/usr/libexec/fprintd"\n  },\n  {\n    "pid": "14428",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "3.1%",\n    "memory": "0.6%",\n    "command": "/usr/bin/nautilus --gapplication-service"\n  },\n  {\n    "pid": "14446",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "6.6%",\n    "memory": "0.7%",\n    "command": "gjs /usr/share/gnome-shell/extensions/ding@rastersoft.com/app/ding.js -E -P /usr/share/gnome-shell/extensions/ding@rastersoft.com/app"\n  },\n  {\n    "pid": "14485",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "./gla1v3-agent-linux"\n  },\n  {\n    "pid": "14497",\n    "name": "",\n    "user": "vagrant",\n    "cpu": "0.0%",\n    "memory": "0.0%",\n    "command": "ps aux"\n  }\n]	\N	\N	\N	0	complete	2026-02-12 23:33:51.198168+00	t
de5fdef1-1863-4c96-aa1d-41773a202464	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	51ab2767-f615-4b95-8dfb-ebafb262e8ca	{\n  "arch": "amd64",\n  "hostname": "Gla1v3-Target-Ubuntu",\n  "kernel": "6.14.0-37-generic",\n  "os": "linux",\n  "os_version": "Ubuntu 24.04.3 LTS"\n}	\N	\N	\N	0	complete	2026-02-12 23:33:51.209182+00	t
bcaa44ac-3ea5-4735-ac2e-a80be0e4dbf6	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	f5021f3a-567c-42ef-a74d-49e9baf142b4	{\n  "has_sudo": true,\n  "is_root": false,\n  "uid": "1000"\n}	\N	\N	\N	0	complete	2026-02-12 23:33:51.215043+00	t
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.tasks (id, tenant_id, agent_id, task_type, embedded_type, embedded_params, run_once, command, args, status, created_at, sent_at, executed_at, completed_at, created_by) FROM stdin;
1a5719b6-1f3f-48b4-9fe6-49c4102fa910	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	embedded	proc_list	{}	f	\N	\N	completed	2026-02-12 23:17:46.82118+00	\N	\N	2026-02-12 23:17:47.554455+00	\N
664116a8-b488-4488-ba77-46621de9906f	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	embedded	proc_list	{}	t	\N	\N	completed	2026-02-12 23:22:52.674761+00	\N	\N	2026-02-12 23:22:52.678071+00	\N
b9f62e0a-6ddf-471c-a632-7ae5414db243	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	embedded	sys_info	{}	t	\N	\N	completed	2026-02-12 23:22:52.68474+00	\N	\N	2026-02-12 23:22:52.687073+00	\N
6b2ccfe8-c367-43d9-a354-8c6aefadf0bb	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	embedded	priv_check	{}	t	\N	\N	completed	2026-02-12 23:22:52.691632+00	\N	\N	2026-02-12 23:22:52.693763+00	\N
fa923445-2a0a-4fd3-848c-768abebe09c0	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	embedded	proc_list	{}	t	\N	\N	completed	2026-02-12 23:33:51.194888+00	\N	\N	2026-02-12 23:33:51.198168+00	\N
51ab2767-f615-4b95-8dfb-ebafb262e8ca	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	embedded	sys_info	{}	t	\N	\N	completed	2026-02-12 23:33:51.205709+00	\N	\N	2026-02-12 23:33:51.209182+00	\N
f5021f3a-567c-42ef-a74d-49e9baf142b4	00000000-0000-0000-0000-000000000001	5f8992da-65f7-485d-b30e-6f2b5404a2d7	embedded	priv_check	{}	t	\N	\N	completed	2026-02-12 23:33:51.213502+00	\N	\N	2026-02-12 23:33:51.215043+00	\N
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.tenants (id, name, api_key, description, active, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	Default	default-tenant-key	Default tenant created during initial setup	t	2026-02-12 21:36:53.358812+00	2026-02-12 21:36:53.358812+00
\.


--
-- Data for Name: user_tenants; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.user_tenants (user_id, tenant_id, assigned_at) FROM stdin;
64737bdb-c2ee-40c8-8af3-b1f20f54d05a	00000000-0000-0000-0000-000000000001	2026-02-12 21:37:49.838907+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.users (id, username, password_hash, role, active, totp_secret, totp_enabled, totp_backup_codes, totp_enabled_at, created_at, updated_at) FROM stdin;
64737bdb-c2ee-40c8-8af3-b1f20f54d05a	admin	$2a$10$cy9MF72L3eGsT/B/5qyH9uv5hlJXsiokpqTHT44DFErJ362IdUwVG	admin	t	\N	f	\N	\N	2026-02-12 21:37:49.833186+00	2026-02-12 21:37:49.833186+00
\.


--
-- Name: agent_blacklist agent_blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agent_blacklist
    ADD CONSTRAINT agent_blacklist_pkey PRIMARY KEY (agent_id, tenant_id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: results results_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_api_key_key; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_api_key_key UNIQUE (api_key);


--
-- Name: tenants tenants_name_key; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_name_key UNIQUE (name);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_tenants user_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_pkey PRIMARY KEY (user_id, tenant_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_agent_blacklist_agent; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agent_blacklist_agent ON public.agent_blacklist USING btree (agent_id);


--
-- Name: idx_agent_blacklist_expires; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agent_blacklist_expires ON public.agent_blacklist USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_agent_blacklist_revoked; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agent_blacklist_revoked ON public.agent_blacklist USING btree (revoked);


--
-- Name: idx_agent_blacklist_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agent_blacklist_tenant ON public.agent_blacklist USING btree (tenant_id);


--
-- Name: idx_agents_cert_expiry; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_cert_expiry ON public.agents USING btree (cert_expiry) WHERE (cert_expiry IS NOT NULL);


--
-- Name: idx_agents_cert_id; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_cert_id ON public.agents USING btree (cert_id) WHERE (cert_id IS NOT NULL);


--
-- Name: idx_agents_cert_status; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_cert_status ON public.agents USING btree (cert_status) WHERE (cert_status <> 'active'::text);


--
-- Name: idx_agents_hostname; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_hostname ON public.agents USING btree (tenant_id, hostname);


--
-- Name: idx_agents_last_seen; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_last_seen ON public.agents USING btree (tenant_id, last_seen DESC);


--
-- Name: idx_agents_status; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_status ON public.agents USING btree (tenant_id, status);


--
-- Name: idx_agents_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_tenant ON public.agents USING btree (tenant_id);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_action ON public.audit_log USING btree (action, "timestamp" DESC);


--
-- Name: idx_audit_resource; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_resource ON public.audit_log USING btree (resource_type, resource_id);


--
-- Name: idx_audit_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_tenant ON public.audit_log USING btree (tenant_id, "timestamp" DESC);


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_user ON public.audit_log USING btree (user_id, "timestamp" DESC);


--
-- Name: idx_results_agent; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_agent ON public.results USING btree (tenant_id, agent_id, "timestamp" DESC);


--
-- Name: idx_results_task; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_task ON public.results USING btree (task_id, stream_index);


--
-- Name: idx_results_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_tenant ON public.results USING btree (tenant_id);


--
-- Name: idx_results_timestamp; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_timestamp ON public.results USING btree (tenant_id, "timestamp" DESC);


--
-- Name: idx_tasks_agent; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_agent ON public.tasks USING btree (tenant_id, agent_id);


--
-- Name: idx_tasks_created; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_created ON public.tasks USING btree (tenant_id, created_at DESC);


--
-- Name: idx_tasks_pending; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_pending ON public.tasks USING btree (agent_id, status) WHERE (status = 'pending'::text);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (tenant_id, agent_id, status);


--
-- Name: idx_tasks_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_tenant ON public.tasks USING btree (tenant_id);


--
-- Name: idx_tenants_active; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tenants_active ON public.tenants USING btree (active);


--
-- Name: idx_tenants_api_key; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tenants_api_key ON public.tenants USING btree (api_key) WHERE (api_key IS NOT NULL);


--
-- Name: idx_user_tenants_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_user_tenants_tenant ON public.user_tenants USING btree (tenant_id);


--
-- Name: idx_user_tenants_user; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_user_tenants_user ON public.user_tenants USING btree (user_id);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_totp_enabled; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_users_totp_enabled ON public.users USING btree (totp_enabled);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: agents update_agents_updated_at; Type: TRIGGER; Schema: public; Owner: gla1v3_app
--

CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tenants update_tenants_updated_at; Type: TRIGGER; Schema: public; Owner: gla1v3_app
--

CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: gla1v3_app
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agent_blacklist agent_blacklist_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agent_blacklist
    ADD CONSTRAINT agent_blacklist_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: agents agents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: results results_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: results results_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: results results_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tasks tasks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_tenants user_tenants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_tenants user_tenants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agents admin_all_agents; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_agents ON public.agents USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: agent_blacklist admin_all_blacklist; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_blacklist ON public.agent_blacklist USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: results admin_all_results; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_results ON public.results USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: tasks admin_all_tasks; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_tasks ON public.tasks USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: tenants admin_all_tenants; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_tenants ON public.tenants USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: agent_blacklist; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.agent_blacklist ENABLE ROW LEVEL SECURITY;

--
-- Name: agents; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants operator_assigned_tenants; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_assigned_tenants ON public.tenants FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = tenants.id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: agents operator_tenant_agents; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_agents ON public.agents USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = agents.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: agent_blacklist operator_tenant_blacklist; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_blacklist ON public.agent_blacklist USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = agent_blacklist.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: results operator_tenant_results; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_results ON public.results USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = results.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: tasks operator_tenant_tasks; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_tasks ON public.tasks USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = tasks.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: results; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.results ENABLE ROW LEVEL SECURITY;

--
-- Name: agents service_agent_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_agent_access ON public.agents USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: agent_blacklist service_blacklist_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_blacklist_access ON public.agent_blacklist USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: results service_result_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_result_access ON public.results USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: tasks service_task_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_task_access ON public.tasks USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: tenants service_tenant_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_tenant_access ON public.tenants FOR SELECT USING ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: tasks; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO gla1v3_api;


--
-- Name: FUNCTION complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text) TO gla1v3_api;


--
-- Name: FUNCTION get_expiring_certificates(days_threshold integer); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_expiring_certificates(days_threshold integer) TO gla1v3_api;


--
-- Name: FUNCTION get_pending_tasks_for_agent(agent_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION get_tenant_stats(tenant_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_tenant_stats(tenant_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION get_user_tenants(user_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_user_tenants(user_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text) TO gla1v3_api;


--
-- Name: FUNCTION mark_stale_agents_inactive(stale_minutes integer); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.mark_stale_agents_inactive(stale_minutes integer) TO gla1v3_api;


--
-- Name: FUNCTION set_current_user(user_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.set_current_user(user_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION update_agent_last_seen(agent_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.update_agent_last_seen(agent_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v1() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v1mc() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v3(namespace uuid, name text) TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v4() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v5(namespace uuid, name text) TO gla1v3_api;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_nil() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_dns() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_oid() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_url() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_x500() TO gla1v3_api;


--
-- Name: TABLE agent_blacklist; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.agent_blacklist TO gla1v3_api;


--
-- Name: TABLE agents; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.agents TO gla1v3_api;


--
-- Name: TABLE audit_log; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.audit_log TO gla1v3_api;


--
-- Name: TABLE results; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.results TO gla1v3_api;


--
-- Name: TABLE tasks; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tasks TO gla1v3_api;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tenants TO gla1v3_api;


--
-- Name: TABLE user_tenants; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_tenants TO gla1v3_api;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO gla1v3_api;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: gla1v3_app
--

ALTER DEFAULT PRIVILEGES FOR ROLE gla1v3_app IN SCHEMA public GRANT ALL ON SEQUENCES TO gla1v3_api;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: gla1v3_app
--

ALTER DEFAULT PRIVILEGES FOR ROLE gla1v3_app IN SCHEMA public GRANT ALL ON FUNCTIONS TO gla1v3_api;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: gla1v3_app
--

ALTER DEFAULT PRIVILEGES FOR ROLE gla1v3_app IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO gla1v3_api;


--
-- PostgreSQL database dump complete
--

\unrestrict 5o0BL4DGEGNXr52VL33xMJHBmQCaSVpWp7mqTKt1cKZpPZ6qDoZzU920gQ5zV0I

