﻿--
-- PostgreSQL database dump
--

\restrict hvaqoO8CuWRYGHHkmKSSTayPeGYQL2FofA1PRjsIAJdtnxZo8RsEWkW4YxNEhD5

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: complete_task(uuid, text, text, integer, text); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.complete_task(task_uuid uuid, task_stdout text DEFAULT NULL::text, task_stderr text DEFAULT NULL::text, task_exit_code integer DEFAULT NULL::integer, task_error text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    result_uuid UUID;
    task_tenant_id UUID;
    task_agent_id UUID;
BEGIN
    -- Get task details
    SELECT tenant_id, agent_id INTO task_tenant_id, task_agent_id
    FROM tasks WHERE id = task_uuid;
    
    -- Update task status
    UPDATE tasks
    SET 
        status = CASE WHEN task_error IS NOT NULL THEN 'failed' ELSE 'completed' END,
        completed_at = NOW()
    WHERE id = task_uuid;
    
    -- Insert result
    INSERT INTO results (
        tenant_id,
        agent_id,
        task_id,
        stdout,
        stderr,
        exit_code,
        error_message,
        completed,
        result_type
    ) VALUES (
        task_tenant_id,
        task_agent_id,
        task_uuid,
        task_stdout,
        task_stderr,
        task_exit_code,
        task_error,
        true,
        'complete'
    ) RETURNING id INTO result_uuid;
    
    RETURN result_uuid;
END;
$$;


ALTER FUNCTION public.complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text) OWNER TO gla1v3_app;

--
-- Name: FUNCTION complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text) IS 'Mark task as complete and store result';


--
-- Name: get_expiring_certificates(integer); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_expiring_certificates(days_threshold integer DEFAULT 30) RETURNS TABLE(agent_id uuid, hostname text, cert_fingerprint text, cert_expiry timestamp with time zone, days_remaining integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id,
        a.hostname,
        a.cert_fingerprint,
        a.cert_expiry,
        EXTRACT(DAY FROM (a.cert_expiry - NOW()))::INTEGER as days_remaining
    FROM agents a
    WHERE a.cert_expiry IS NOT NULL
    AND a.cert_expiry <= NOW() + (days_threshold || ' days')::INTERVAL
    AND a.cert_status = 'active'
    ORDER BY a.cert_expiry ASC;
END;
$$;


ALTER FUNCTION public.get_expiring_certificates(days_threshold integer) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_expiring_certificates(days_threshold integer); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_expiring_certificates(days_threshold integer) IS 'Get agents with certificates expiring soon';


--
-- Name: get_pending_tasks_for_agent(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) RETURNS TABLE(task_id uuid, task_type text, command text, args jsonb, embedded_type text, embedded_params jsonb, run_once boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Mark tasks as sent
    UPDATE tasks
    SET status = 'sent', sent_at = NOW()
    WHERE agent_id = agent_uuid
    AND status = 'pending';
    
    -- Return the tasks
    RETURN QUERY
    SELECT 
        t.id,
        t.task_type,
        t.command,
        t.args,
        t.embedded_type,
        t.embedded_params,
        t.run_once,
        t.created_at
    FROM tasks t
    WHERE t.agent_id = agent_uuid
    AND t.status = 'sent'
    ORDER BY t.created_at ASC;
END;
$$;


ALTER FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_pending_tasks_for_agent(agent_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) IS 'Atomically get and mark tasks as sent for an agent';


--
-- Name: get_tenant_stats(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_tenant_stats(tenant_uuid uuid) RETURNS TABLE(total_agents bigint, active_agents bigint, inactive_agents bigint, total_tasks bigint, pending_tasks bigint, completed_tasks bigint, failed_tasks bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        COUNT(DISTINCT a.id),
        COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'active'),
        COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'inactive'),
        COUNT(DISTINCT t.id),
        COUNT(DISTINCT t.id) FILTER (WHERE t.status IN ('pending', 'sent')),
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'completed'),
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'failed')
    FROM tenants tn
    LEFT JOIN agents a ON a.tenant_id = tn.id
    LEFT JOIN tasks t ON t.tenant_id = tn.id
    WHERE tn.id = tenant_uuid
    GROUP BY tn.id;
END;
$$;


ALTER FUNCTION public.get_tenant_stats(tenant_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_tenant_stats(tenant_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_tenant_stats(tenant_uuid uuid) IS 'Get statistics for a specific tenant';


--
-- Name: get_user_tenants(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_user_tenants(user_uuid uuid) RETURNS TABLE(tenant_id uuid, tenant_name text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- If admin, return all tenants
    IF EXISTS (SELECT 1 FROM users WHERE id = user_uuid AND role = 'admin') THEN
        RETURN QUERY
        SELECT t.id, t.name
        FROM tenants t
        WHERE t.active = true
        ORDER BY t.name;
    ELSE
        -- If operator, return only assigned tenants
        RETURN QUERY
        SELECT t.id, t.name
        FROM tenants t
        INNER JOIN user_tenants ut ON ut.tenant_id = t.id
        WHERE ut.user_id = user_uuid
        AND t.active = true
        ORDER BY t.name;
    END IF;
END;
$$;


ALTER FUNCTION public.get_user_tenants(user_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_user_tenants(user_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_user_tenants(user_uuid uuid) IS 'Get all tenants accessible by a user. Admins see all, operators see assigned.';


--
-- Name: log_audit(uuid, uuid, text, text, uuid, jsonb, inet, text); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text DEFAULT NULL::text, p_resource_id uuid DEFAULT NULL::uuid, p_details jsonb DEFAULT NULL::jsonb, p_ip_address inet DEFAULT NULL::inet, p_user_agent text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    log_id UUID;
BEGIN
    INSERT INTO audit_log (
        user_id,
        tenant_id,
        action,
        resource_type,
        resource_id,
        details,
        ip_address,
        user_agent
    ) VALUES (
        p_user_id,
        p_tenant_id,
        p_action,
        p_resource_type,
        p_resource_id,
        p_details,
        p_ip_address,
        p_user_agent
    ) RETURNING id INTO log_id;
    
    RETURN log_id;
END;
$$;


ALTER FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text) OWNER TO gla1v3_app;

--
-- Name: FUNCTION log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text) IS 'Log an audit event';


--
-- Name: mark_stale_agents_inactive(integer); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.mark_stale_agents_inactive(stale_minutes integer DEFAULT 60) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    affected_count INTEGER;
BEGIN
    UPDATE agents
    SET status = 'inactive'
    WHERE status = 'active'
    AND last_seen < NOW() - (stale_minutes || ' minutes')::INTERVAL;
    
    GET DIAGNOSTICS affected_count = ROW_COUNT;
    RETURN affected_count;
END;
$$;


ALTER FUNCTION public.mark_stale_agents_inactive(stale_minutes integer) OWNER TO gla1v3_app;

--
-- Name: FUNCTION mark_stale_agents_inactive(stale_minutes integer); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.mark_stale_agents_inactive(stale_minutes integer) IS 'Mark agents that haven''t checked in as inactive';


--
-- Name: set_current_user(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.set_current_user(user_uuid uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Set for transaction (false = transaction-local, will be cleared after transaction)
    -- The application should use queryWithContext() to ensure proper context per query
    PERFORM set_config('app.current_user_id', user_uuid::text, false);
END;
$$;


ALTER FUNCTION public.set_current_user(user_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION set_current_user(user_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.set_current_user(user_uuid uuid) IS 'Set the current user context for RLS policies. Call this after authentication.';


--
-- Name: update_agent_last_seen(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.update_agent_last_seen(agent_uuid uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE agents
    SET last_seen = NOW()
    WHERE id = agent_uuid;
END;
$$;


ALTER FUNCTION public.update_agent_last_seen(agent_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO gla1v3_app;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.agents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    hostname text NOT NULL,
    cn text,
    os text,
    arch text,
    username text,
    ip_address inet,
    latitude double precision,
    longitude double precision,
    geo_country text,
    geo_region text,
    geo_city text,
    cert_fingerprint text,
    cert_issued_at timestamp with time zone,
    cert_expiry timestamp with time zone,
    cert_status text DEFAULT 'active'::text,
    status text DEFAULT 'active'::text,
    first_seen timestamp with time zone DEFAULT now(),
    last_seen timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    cert_id text,
    CONSTRAINT agents_cert_status_check CHECK ((cert_status = ANY (ARRAY['active'::text, 'revoked'::text, 'expired'::text, 'pending'::text]))),
    CONSTRAINT agents_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text, 'compromised'::text, 'removed'::text])))
);


ALTER TABLE public.agents OWNER TO gla1v3_app;

--
-- Name: TABLE agents; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.agents IS 'Compromised hosts running Gla1v3 agents';


--
-- Name: COLUMN agents.cert_id; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.agents.cert_id IS 'Certificate ID from CA service for dynamic cert management';


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    action text NOT NULL,
    resource_type text,
    resource_id uuid,
    details jsonb,
    ip_address inet,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO gla1v3_app;

--
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.audit_log IS 'Audit trail of all administrative actions';


--
-- Name: results; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.results (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    task_id uuid NOT NULL,
    stdout text,
    stderr text,
    exit_code integer,
    error_message text,
    stream_index integer DEFAULT 0,
    result_type text DEFAULT 'complete'::text,
    "timestamp" timestamp with time zone DEFAULT now(),
    completed boolean DEFAULT false,
    CONSTRAINT results_result_type_check CHECK ((result_type = ANY (ARRAY['stdout'::text, 'stderr'::text, 'error'::text, 'complete'::text, 'progress'::text])))
);


ALTER TABLE public.results OWNER TO gla1v3_app;

--
-- Name: TABLE results; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.results IS 'Task execution results and output streams';


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.tasks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    task_type text,
    embedded_type text,
    embedded_params jsonb,
    run_once boolean DEFAULT false,
    command text,
    args jsonb,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT now(),
    sent_at timestamp with time zone,
    executed_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_by uuid,
    CONSTRAINT task_type_check CHECK ((((task_type = 'embedded'::text) AND (embedded_type IS NOT NULL)) OR ((task_type = 'command'::text) AND (command IS NOT NULL)) OR ((task_type IS NULL) AND (command IS NOT NULL)))),
    CONSTRAINT tasks_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'running'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
);


ALTER TABLE public.tasks OWNER TO gla1v3_app;

--
-- Name: TABLE tasks; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.tasks IS 'Commands queued for execution on agents';


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    api_key text,
    description text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tenants OWNER TO gla1v3_app;

--
-- Name: TABLE tenants; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.tenants IS 'Client companies being assessed by red team';


--
-- Name: user_tenants; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.user_tenants (
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    assigned_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_tenants OWNER TO gla1v3_app;

--
-- Name: TABLE user_tenants; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.user_tenants IS 'Maps which users can access which tenant data';


--
-- Name: users; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'operator'::text NOT NULL,
    active boolean DEFAULT true,
    totp_secret text,
    totp_enabled boolean DEFAULT false,
    totp_backup_codes text[],
    totp_enabled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'operator'::text])))
);


ALTER TABLE public.users OWNER TO gla1v3_app;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.users IS 'Red team operators and administrators';


--
-- Name: COLUMN users.totp_secret; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_secret IS 'Encrypted TOTP secret for 2FA';


--
-- Name: COLUMN users.totp_enabled; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_enabled IS 'Whether 2FA is enabled for this user';


--
-- Name: COLUMN users.totp_backup_codes; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_backup_codes IS 'Array of bcrypt-hashed backup codes for account recovery';


--
-- Name: COLUMN users.totp_enabled_at; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_enabled_at IS 'Timestamp when 2FA was enabled';


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.agents (id, tenant_id, hostname, cn, os, arch, username, ip_address, latitude, longitude, geo_country, geo_region, geo_city, cert_fingerprint, cert_issued_at, cert_expiry, cert_status, status, first_seen, last_seen, created_at, updated_at, cert_id) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.audit_log (id, tenant_id, user_id, action, resource_type, resource_id, details, ip_address, user_agent, "timestamp") FROM stdin;
\.


--
-- Data for Name: results; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.results (id, tenant_id, agent_id, task_id, stdout, stderr, exit_code, error_message, stream_index, result_type, "timestamp", completed) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.tasks (id, tenant_id, agent_id, task_type, embedded_type, embedded_params, run_once, command, args, status, created_at, sent_at, executed_at, completed_at, created_by) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.tenants (id, name, api_key, description, active, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	Default	default-tenant-key	Default tenant created during initial setup	t	2026-02-12 00:06:11.542734+00	2026-02-12 00:06:11.542734+00
\.


--
-- Data for Name: user_tenants; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.user_tenants (user_id, tenant_id, assigned_at) FROM stdin;
283f383e-d94f-4aff-a276-3f8a7cd26eea	00000000-0000-0000-0000-000000000001	2026-02-12 13:36:21.557216+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.users (id, username, password_hash, role, active, totp_secret, totp_enabled, totp_backup_codes, totp_enabled_at, created_at, updated_at) FROM stdin;
283f383e-d94f-4aff-a276-3f8a7cd26eea	admin	$2b$10$iagFLoVMOIkO3D.rx66IF.9RAZCBhjL9j/9.IHD0D4WV5JEzA7sXm	admin	t	\N	f	\N	\N	2026-02-12 13:36:21.544814+00	2026-02-12 13:36:21.544814+00
\.


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: results results_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_api_key_key; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_api_key_key UNIQUE (api_key);


--
-- Name: tenants tenants_name_key; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_name_key UNIQUE (name);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: user_tenants user_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_pkey PRIMARY KEY (user_id, tenant_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_agents_cert_expiry; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_cert_expiry ON public.agents USING btree (cert_expiry) WHERE (cert_expiry IS NOT NULL);


--
-- Name: idx_agents_cert_id; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_cert_id ON public.agents USING btree (cert_id) WHERE (cert_id IS NOT NULL);


--
-- Name: idx_agents_cert_status; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_cert_status ON public.agents USING btree (cert_status) WHERE (cert_status <> 'active'::text);


--
-- Name: idx_agents_hostname; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_hostname ON public.agents USING btree (tenant_id, hostname);


--
-- Name: idx_agents_last_seen; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_last_seen ON public.agents USING btree (tenant_id, last_seen DESC);


--
-- Name: idx_agents_status; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_status ON public.agents USING btree (tenant_id, status);


--
-- Name: idx_agents_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_tenant ON public.agents USING btree (tenant_id);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_action ON public.audit_log USING btree (action, "timestamp" DESC);


--
-- Name: idx_audit_resource; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_resource ON public.audit_log USING btree (resource_type, resource_id);


--
-- Name: idx_audit_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_tenant ON public.audit_log USING btree (tenant_id, "timestamp" DESC);


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_user ON public.audit_log USING btree (user_id, "timestamp" DESC);


--
-- Name: idx_results_agent; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_agent ON public.results USING btree (tenant_id, agent_id, "timestamp" DESC);


--
-- Name: idx_results_task; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_task ON public.results USING btree (task_id, stream_index);


--
-- Name: idx_results_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_tenant ON public.results USING btree (tenant_id);


--
-- Name: idx_results_timestamp; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_timestamp ON public.results USING btree (tenant_id, "timestamp" DESC);


--
-- Name: idx_tasks_agent; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_agent ON public.tasks USING btree (tenant_id, agent_id);


--
-- Name: idx_tasks_created; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_created ON public.tasks USING btree (tenant_id, created_at DESC);


--
-- Name: idx_tasks_pending; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_pending ON public.tasks USING btree (agent_id, status) WHERE (status = 'pending'::text);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (tenant_id, agent_id, status);


--
-- Name: idx_tasks_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_tenant ON public.tasks USING btree (tenant_id);


--
-- Name: idx_tenants_active; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tenants_active ON public.tenants USING btree (active);


--
-- Name: idx_tenants_api_key; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tenants_api_key ON public.tenants USING btree (api_key) WHERE (api_key IS NOT NULL);


--
-- Name: idx_user_tenants_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_user_tenants_tenant ON public.user_tenants USING btree (tenant_id);


--
-- Name: idx_user_tenants_user; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_user_tenants_user ON public.user_tenants USING btree (user_id);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_totp_enabled; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_users_totp_enabled ON public.users USING btree (totp_enabled);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: agents update_agents_updated_at; Type: TRIGGER; Schema: public; Owner: gla1v3_app
--

CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tenants update_tenants_updated_at; Type: TRIGGER; Schema: public; Owner: gla1v3_app
--

CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: gla1v3_app
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agents agents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: results results_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: results results_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: results results_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tasks tasks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_tenants user_tenants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_tenants user_tenants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agents admin_all_agents; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_agents ON public.agents USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: results admin_all_results; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_results ON public.results USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: tasks admin_all_tasks; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_tasks ON public.tasks USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: tenants admin_all_tenants; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_tenants ON public.tenants USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: agents; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants operator_assigned_tenants; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_assigned_tenants ON public.tenants FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = tenants.id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: agents operator_tenant_agents; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_agents ON public.agents USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = agents.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: results operator_tenant_results; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_results ON public.results USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = results.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: tasks operator_tenant_tasks; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_tasks ON public.tasks USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = tasks.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: results; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.results ENABLE ROW LEVEL SECURITY;

--
-- Name: agents service_agent_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_agent_access ON public.agents USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: results service_result_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_result_access ON public.results USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: tasks service_task_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_task_access ON public.tasks USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: tenants service_tenant_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_tenant_access ON public.tenants FOR SELECT USING ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: tasks; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO gla1v3_api;


--
-- Name: FUNCTION complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text) TO gla1v3_api;


--
-- Name: FUNCTION get_expiring_certificates(days_threshold integer); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_expiring_certificates(days_threshold integer) TO gla1v3_api;


--
-- Name: FUNCTION get_pending_tasks_for_agent(agent_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION get_tenant_stats(tenant_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_tenant_stats(tenant_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION get_user_tenants(user_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_user_tenants(user_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text) TO gla1v3_api;


--
-- Name: FUNCTION mark_stale_agents_inactive(stale_minutes integer); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.mark_stale_agents_inactive(stale_minutes integer) TO gla1v3_api;


--
-- Name: FUNCTION set_current_user(user_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.set_current_user(user_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION update_agent_last_seen(agent_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.update_agent_last_seen(agent_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v1() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v1mc() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v3(namespace uuid, name text) TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v4() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v5(namespace uuid, name text) TO gla1v3_api;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_nil() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_dns() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_oid() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_url() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_x500() TO gla1v3_api;


--
-- Name: TABLE agents; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.agents TO gla1v3_api;


--
-- Name: TABLE audit_log; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.audit_log TO gla1v3_api;


--
-- Name: TABLE results; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.results TO gla1v3_api;


--
-- Name: TABLE tasks; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tasks TO gla1v3_api;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tenants TO gla1v3_api;


--
-- Name: TABLE user_tenants; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_tenants TO gla1v3_api;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO gla1v3_api;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: gla1v3_app
--

ALTER DEFAULT PRIVILEGES FOR ROLE gla1v3_app IN SCHEMA public GRANT ALL ON SEQUENCES TO gla1v3_api;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: gla1v3_app
--

ALTER DEFAULT PRIVILEGES FOR ROLE gla1v3_app IN SCHEMA public GRANT ALL ON FUNCTIONS TO gla1v3_api;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: gla1v3_app
--

ALTER DEFAULT PRIVILEGES FOR ROLE gla1v3_app IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO gla1v3_api;


--
-- PostgreSQL database dump complete
--

\unrestrict hvaqoO8CuWRYGHHkmKSSTayPeGYQL2FofA1PRjsIAJdtnxZo8RsEWkW4YxNEhD5

