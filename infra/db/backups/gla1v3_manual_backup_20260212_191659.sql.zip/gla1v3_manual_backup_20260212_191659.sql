﻿--
-- PostgreSQL database dump
--

\restrict PG2rkblgePHpjlCzS9UjNfgMVrR6BbHdJWTqCcXdvSNJgpaLpbgLkrcGvtFm0Ng

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: complete_task(uuid, text, text, integer, text); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.complete_task(task_uuid uuid, task_stdout text DEFAULT NULL::text, task_stderr text DEFAULT NULL::text, task_exit_code integer DEFAULT NULL::integer, task_error text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    result_uuid UUID;
    task_tenant_id UUID;
    task_agent_id UUID;
BEGIN
    -- Get task details
    SELECT tenant_id, agent_id INTO task_tenant_id, task_agent_id
    FROM tasks WHERE id = task_uuid;
    
    -- Update task status
    UPDATE tasks
    SET 
        status = CASE WHEN task_error IS NOT NULL THEN 'failed' ELSE 'completed' END,
        completed_at = NOW()
    WHERE id = task_uuid;
    
    -- Insert result
    INSERT INTO results (
        tenant_id,
        agent_id,
        task_id,
        stdout,
        stderr,
        exit_code,
        error_message,
        completed,
        result_type
    ) VALUES (
        task_tenant_id,
        task_agent_id,
        task_uuid,
        task_stdout,
        task_stderr,
        task_exit_code,
        task_error,
        true,
        'complete'
    ) RETURNING id INTO result_uuid;
    
    RETURN result_uuid;
END;
$$;


ALTER FUNCTION public.complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text) OWNER TO gla1v3_app;

--
-- Name: FUNCTION complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text) IS 'Mark task as complete and store result';


--
-- Name: get_expiring_certificates(integer); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_expiring_certificates(days_threshold integer DEFAULT 30) RETURNS TABLE(agent_id uuid, hostname text, cert_fingerprint text, cert_expiry timestamp with time zone, days_remaining integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        a.id,
        a.hostname,
        a.cert_fingerprint,
        a.cert_expiry,
        EXTRACT(DAY FROM (a.cert_expiry - NOW()))::INTEGER as days_remaining
    FROM agents a
    WHERE a.cert_expiry IS NOT NULL
    AND a.cert_expiry <= NOW() + (days_threshold || ' days')::INTERVAL
    AND a.cert_status = 'active'
    ORDER BY a.cert_expiry ASC;
END;
$$;


ALTER FUNCTION public.get_expiring_certificates(days_threshold integer) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_expiring_certificates(days_threshold integer); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_expiring_certificates(days_threshold integer) IS 'Get agents with certificates expiring soon';


--
-- Name: get_pending_tasks_for_agent(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) RETURNS TABLE(task_id uuid, task_type text, command text, args jsonb, embedded_type text, embedded_params jsonb, run_once boolean, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Mark tasks as sent
    UPDATE tasks
    SET status = 'sent', sent_at = NOW()
    WHERE agent_id = agent_uuid
    AND status = 'pending';
    
    -- Return the tasks
    RETURN QUERY
    SELECT 
        t.id,
        t.task_type,
        t.command,
        t.args,
        t.embedded_type,
        t.embedded_params,
        t.run_once,
        t.created_at
    FROM tasks t
    WHERE t.agent_id = agent_uuid
    AND t.status = 'sent'
    ORDER BY t.created_at ASC;
END;
$$;


ALTER FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_pending_tasks_for_agent(agent_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) IS 'Atomically get and mark tasks as sent for an agent';


--
-- Name: get_tenant_stats(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_tenant_stats(tenant_uuid uuid) RETURNS TABLE(total_agents bigint, active_agents bigint, inactive_agents bigint, total_tasks bigint, pending_tasks bigint, completed_tasks bigint, failed_tasks bigint)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT
        COUNT(DISTINCT a.id),
        COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'active'),
        COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'inactive'),
        COUNT(DISTINCT t.id),
        COUNT(DISTINCT t.id) FILTER (WHERE t.status IN ('pending', 'sent')),
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'completed'),
        COUNT(DISTINCT t.id) FILTER (WHERE t.status = 'failed')
    FROM tenants tn
    LEFT JOIN agents a ON a.tenant_id = tn.id
    LEFT JOIN tasks t ON t.tenant_id = tn.id
    WHERE tn.id = tenant_uuid
    GROUP BY tn.id;
END;
$$;


ALTER FUNCTION public.get_tenant_stats(tenant_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_tenant_stats(tenant_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_tenant_stats(tenant_uuid uuid) IS 'Get statistics for a specific tenant';


--
-- Name: get_user_tenants(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.get_user_tenants(user_uuid uuid) RETURNS TABLE(tenant_id uuid, tenant_name text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- If admin, return all tenants
    IF EXISTS (SELECT 1 FROM users WHERE id = user_uuid AND role = 'admin') THEN
        RETURN QUERY
        SELECT t.id, t.name
        FROM tenants t
        WHERE t.active = true
        ORDER BY t.name;
    ELSE
        -- If operator, return only assigned tenants
        RETURN QUERY
        SELECT t.id, t.name
        FROM tenants t
        INNER JOIN user_tenants ut ON ut.tenant_id = t.id
        WHERE ut.user_id = user_uuid
        AND t.active = true
        ORDER BY t.name;
    END IF;
END;
$$;


ALTER FUNCTION public.get_user_tenants(user_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION get_user_tenants(user_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.get_user_tenants(user_uuid uuid) IS 'Get all tenants accessible by a user. Admins see all, operators see assigned.';


--
-- Name: log_audit(uuid, uuid, text, text, uuid, jsonb, inet, text); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text DEFAULT NULL::text, p_resource_id uuid DEFAULT NULL::uuid, p_details jsonb DEFAULT NULL::jsonb, p_ip_address inet DEFAULT NULL::inet, p_user_agent text DEFAULT NULL::text) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    log_id UUID;
BEGIN
    INSERT INTO audit_log (
        user_id,
        tenant_id,
        action,
        resource_type,
        resource_id,
        details,
        ip_address,
        user_agent
    ) VALUES (
        p_user_id,
        p_tenant_id,
        p_action,
        p_resource_type,
        p_resource_id,
        p_details,
        p_ip_address,
        p_user_agent
    ) RETURNING id INTO log_id;
    
    RETURN log_id;
END;
$$;


ALTER FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text) OWNER TO gla1v3_app;

--
-- Name: FUNCTION log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text) IS 'Log an audit event';


--
-- Name: mark_stale_agents_inactive(integer); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.mark_stale_agents_inactive(stale_minutes integer DEFAULT 60) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    affected_count INTEGER;
BEGIN
    UPDATE agents
    SET status = 'inactive'
    WHERE status = 'active'
    AND last_seen < NOW() - (stale_minutes || ' minutes')::INTERVAL;
    
    GET DIAGNOSTICS affected_count = ROW_COUNT;
    RETURN affected_count;
END;
$$;


ALTER FUNCTION public.mark_stale_agents_inactive(stale_minutes integer) OWNER TO gla1v3_app;

--
-- Name: FUNCTION mark_stale_agents_inactive(stale_minutes integer); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.mark_stale_agents_inactive(stale_minutes integer) IS 'Mark agents that haven''t checked in as inactive';


--
-- Name: set_current_user(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.set_current_user(user_uuid uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Set for transaction (false = transaction-local, will be cleared after transaction)
    -- The application should use queryWithContext() to ensure proper context per query
    PERFORM set_config('app.current_user_id', user_uuid::text, false);
END;
$$;


ALTER FUNCTION public.set_current_user(user_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: FUNCTION set_current_user(user_uuid uuid); Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON FUNCTION public.set_current_user(user_uuid uuid) IS 'Set the current user context for RLS policies. Call this after authentication.';


--
-- Name: update_agent_last_seen(uuid); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.update_agent_last_seen(agent_uuid uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE agents
    SET last_seen = NOW()
    WHERE id = agent_uuid;
END;
$$;


ALTER FUNCTION public.update_agent_last_seen(agent_uuid uuid) OWNER TO gla1v3_app;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: gla1v3_app
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO gla1v3_app;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_blacklist; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.agent_blacklist (
    id integer NOT NULL,
    agent_id text NOT NULL,
    tenant_id uuid NOT NULL,
    reason text NOT NULL,
    blacklisted_by uuid,
    blacklisted_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone,
    revoked boolean DEFAULT false,
    revoked_at timestamp with time zone,
    revoked_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.agent_blacklist OWNER TO gla1v3_app;

--
-- Name: TABLE agent_blacklist; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.agent_blacklist IS 'Persistent storage for agent blacklist entries with TTL and revocation support';


--
-- Name: COLUMN agent_blacklist.agent_id; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.agent_blacklist.agent_id IS 'Agent identifier (can be UUID from agents.id or CN from certificate)';


--
-- Name: COLUMN agent_blacklist.revoked; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.agent_blacklist.revoked IS 'Whether this blacklist entry was manually revoked before expiry';


--
-- Name: agent_blacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: gla1v3_app
--

CREATE SEQUENCE public.agent_blacklist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_blacklist_id_seq OWNER TO gla1v3_app;

--
-- Name: agent_blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gla1v3_app
--

ALTER SEQUENCE public.agent_blacklist_id_seq OWNED BY public.agent_blacklist.id;


--
-- Name: agents; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.agents (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    hostname text NOT NULL,
    cn text,
    os text,
    arch text,
    username text,
    ip_address inet,
    latitude double precision,
    longitude double precision,
    geo_country text,
    geo_region text,
    geo_city text,
    cert_fingerprint text,
    cert_issued_at timestamp with time zone,
    cert_expiry timestamp with time zone,
    cert_status text DEFAULT 'active'::text,
    status text DEFAULT 'active'::text,
    first_seen timestamp with time zone DEFAULT now(),
    last_seen timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    cert_id text,
    CONSTRAINT agents_cert_status_check CHECK ((cert_status = ANY (ARRAY['active'::text, 'revoked'::text, 'expired'::text, 'pending'::text]))),
    CONSTRAINT agents_status_check CHECK ((status = ANY (ARRAY['active'::text, 'inactive'::text, 'compromised'::text, 'removed'::text])))
);


ALTER TABLE public.agents OWNER TO gla1v3_app;

--
-- Name: TABLE agents; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.agents IS 'Compromised hosts running Gla1v3 agents';


--
-- Name: COLUMN agents.cert_id; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.agents.cert_id IS 'Certificate ID from CA service for dynamic cert management';


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid,
    user_id uuid,
    action text NOT NULL,
    resource_type text,
    resource_id uuid,
    details jsonb,
    ip_address inet,
    user_agent text,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO gla1v3_app;

--
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.audit_log IS 'Audit trail of all administrative actions';


--
-- Name: results; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.results (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    task_id uuid NOT NULL,
    stdout text,
    stderr text,
    exit_code integer,
    error_message text,
    stream_index integer DEFAULT 0,
    result_type text DEFAULT 'complete'::text,
    "timestamp" timestamp with time zone DEFAULT now(),
    completed boolean DEFAULT false,
    CONSTRAINT results_result_type_check CHECK ((result_type = ANY (ARRAY['stdout'::text, 'stderr'::text, 'error'::text, 'complete'::text, 'progress'::text])))
);


ALTER TABLE public.results OWNER TO gla1v3_app;

--
-- Name: TABLE results; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.results IS 'Task execution results and output streams';


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.tasks (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    task_type text,
    embedded_type text,
    embedded_params jsonb,
    run_once boolean DEFAULT false,
    command text,
    args jsonb,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT now(),
    sent_at timestamp with time zone,
    executed_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_by uuid,
    CONSTRAINT task_type_check CHECK ((((task_type = 'embedded'::text) AND (embedded_type IS NOT NULL)) OR ((task_type = 'command'::text) AND (command IS NOT NULL)) OR ((task_type IS NULL) AND (command IS NOT NULL)))),
    CONSTRAINT tasks_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'sent'::text, 'running'::text, 'completed'::text, 'failed'::text, 'cancelled'::text])))
);


ALTER TABLE public.tasks OWNER TO gla1v3_app;

--
-- Name: TABLE tasks; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.tasks IS 'Commands queued for execution on agents';


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    api_key text,
    description text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tenants OWNER TO gla1v3_app;

--
-- Name: TABLE tenants; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.tenants IS 'Client companies being assessed by red team';


--
-- Name: user_tenants; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.user_tenants (
    user_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    assigned_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.user_tenants OWNER TO gla1v3_app;

--
-- Name: TABLE user_tenants; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.user_tenants IS 'Maps which users can access which tenant data';


--
-- Name: users; Type: TABLE; Schema: public; Owner: gla1v3_app
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'operator'::text NOT NULL,
    active boolean DEFAULT true,
    totp_secret text,
    totp_enabled boolean DEFAULT false,
    totp_backup_codes text[],
    totp_enabled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'operator'::text])))
);


ALTER TABLE public.users OWNER TO gla1v3_app;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON TABLE public.users IS 'Red team operators and administrators';


--
-- Name: COLUMN users.totp_secret; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_secret IS 'Encrypted TOTP secret for 2FA';


--
-- Name: COLUMN users.totp_enabled; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_enabled IS 'Whether 2FA is enabled for this user';


--
-- Name: COLUMN users.totp_backup_codes; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_backup_codes IS 'Array of bcrypt-hashed backup codes for account recovery';


--
-- Name: COLUMN users.totp_enabled_at; Type: COMMENT; Schema: public; Owner: gla1v3_app
--

COMMENT ON COLUMN public.users.totp_enabled_at IS 'Timestamp when 2FA was enabled';


--
-- Name: agent_blacklist id; Type: DEFAULT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agent_blacklist ALTER COLUMN id SET DEFAULT nextval('public.agent_blacklist_id_seq'::regclass);


--
-- Data for Name: agent_blacklist; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.agent_blacklist (id, agent_id, tenant_id, reason, blacklisted_by, blacklisted_at, expires_at, revoked, revoked_at, revoked_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.agents (id, tenant_id, hostname, cn, os, arch, username, ip_address, latitude, longitude, geo_country, geo_region, geo_city, cert_fingerprint, cert_issued_at, cert_expiry, cert_status, status, first_seen, last_seen, created_at, updated_at, cert_id) FROM stdin;
9e25666f-c470-40f9-9f2f-e947cb12526e	00000000-0000-0000-0000-000000000001	Gla1v3-Target-Ubuntu	test	linux	amd64	vagrant	87.52.109.250	55.6802	12.5892	DK	84	Copenhagen	\N	\N	\N	active	active	2026-02-12 17:45:09.941562+00	2026-02-12 18:16:57.282526+00	2026-02-12 17:45:09.941562+00	2026-02-12 18:16:57.282526+00	test-test-1770918309876
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.audit_log (id, tenant_id, user_id, action, resource_type, resource_id, details, ip_address, user_agent, "timestamp") FROM stdin;
\.


--
-- Data for Name: results; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.results (id, tenant_id, agent_id, task_id, stdout, stderr, exit_code, error_message, stream_index, result_type, "timestamp", completed) FROM stdin;
767a3b4b-2eec-40fb-ae47-65fa19d06087	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:45:40.435073+00	t
81189db4-a741-4de4-aa1d-59582a5e7bff	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:45:50.596476+00	t
6e69b154-9eb0-43c9-b1e8-5ace8193c5c9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:46:00.733965+00	t
1eefdc05-5db6-4083-9471-b8d0ca848eb6	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:46:10.921235+00	t
0451bbc0-dab8-4e69-98d5-9e0754d9ecec	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:46:21.02195+00	t
3999b268-588f-4177-87bf-1ccca41a4659	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:46:31.13774+00	t
50097551-8a42-49da-8253-bcfb5cc1f6ac	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:46:41.268686+00	t
91f0cc08-e19f-4895-9e97-b3787bb0d28e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:56:58.884251+00	t
f8387277-a677-44bb-a5c1-da3317e1deee	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:56:58.894237+00	t
e3790358-d5dd-4599-bf4f-3e234249896b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:09.117965+00	t
65c5f83b-ce96-468c-a7e8-c89192c385b2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:09.1255+00	t
11ee737c-87fe-4a76-b83a-f6249d62dead	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:19.241976+00	t
03255253-1fa0-4cb7-8e86-7765e87aa12e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:19.267377+00	t
3a5623e4-2026-4d44-80c1-9ae4fd08186a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:29.416197+00	t
9f5639bf-fa51-4ff3-b525-769c1dcbf2c2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:29.443177+00	t
a5ac22c8-dbcd-4607-b50d-03d54a3f2902	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:39.557401+00	t
efa97564-1d9e-42ad-8598-73b7986b6d37	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:39.561617+00	t
23d03f07-1ad7-476b-9eb7-46101bdaf1b6	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:49.688771+00	t
d1ff847e-9c1e-4907-bd85-5e4a03ae83f4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:49.695986+00	t
b4138173-366e-49d9-8209-3246ce08d099	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:59.844618+00	t
750aba8e-07a1-4761-a078-22e40209f1c5	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:57:59.882259+00	t
4223e25e-e376-44d2-9923-aecb43869933	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:09.985244+00	t
7a14aad3-c4c2-482d-bd57-50cfd00c02a8	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:09.985794+00	t
9e2c4a00-e6bc-4f40-b139-624f21ae7a01	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:20.12981+00	t
c41791fc-ed11-4a38-8a9a-bbf591f61e69	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:20.157416+00	t
a9df9d14-8f38-4d25-9a85-91b7aac03a7d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:30.312594+00	t
5c6a413c-a313-4e04-8aee-7a7cd8031268	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:30.315184+00	t
1e1793c7-117d-416a-bc3f-8ae6c6fcbfb0	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:30.316793+00	t
047e927a-f86d-42d9-9cf2-6fa46d910960	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:40.429523+00	t
c2b73473-9c86-4d71-a4e4-dff1b77eed1e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:40.431442+00	t
e88f347b-db4f-49ec-8c86-99e0a4c2f771	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:40.433579+00	t
563a1b59-b6a0-4eee-ae1a-97e5d4b8199c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:50.561318+00	t
6836f0a0-1149-4ce7-a8b7-becb838f1a68	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:50.57414+00	t
f594ce21-62f2-466c-a41b-c1c477e49952	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:58:50.597807+00	t
9345e820-9829-40d7-b087-17378af5aa6c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:00.706505+00	t
8fda1e40-b35a-474a-982e-b8384a0131fe	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:00.732431+00	t
264f3672-766e-4bd8-b345-d3b5e52e7a88	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:00.734563+00	t
21caa658-d2c0-4479-8296-8a7e247210cb	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:10.825802+00	t
c0677235-a7b9-4258-bb58-ee826849febd	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:10.849511+00	t
2e87f5ae-ac78-4dc8-abc7-3f3ffa7074d2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:10.85191+00	t
bf461831-da76-4089-bde0-e937adc295c3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:20.991307+00	t
141b6973-a2a4-4fda-a305-1cf56d107b2d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:20.993448+00	t
1066ccde-46e8-44ca-b989-a98239ebafe1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:20.99446+00	t
639192f6-acd4-414e-b57a-5e5fe65f7f54	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:31.078384+00	t
d401a0e7-636d-44c9-88c9-fb07d20b354d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:31.080347+00	t
6484ad16-e973-40be-9352-53d7896f27c2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:31.082318+00	t
ea929d50-2efe-46b5-95b3-70ecfbb88f0f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:41.226119+00	t
484f9af0-acce-4c2c-a064-44ad0d7efb77	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:41.25105+00	t
bb2c7ed3-2a0b-4b84-93fc-c5b1cc0882d7	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:41.258946+00	t
020cb7ad-db62-4e92-8e5e-788dac4ea16e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:51.379789+00	t
f70d0462-9be6-4ca0-a9dc-27a5f106fcfd	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:51.418888+00	t
50cab823-0392-4a06-bf76-cacba6248816	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 17:59:51.425366+00	t
4a8a6881-7e0b-4988-88ee-7da80c9ee54d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:01.534574+00	t
c0db9057-c077-4960-8201-9cda87d72b2b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:01.542803+00	t
1088e6e9-899e-4e82-b94a-b23652258dde	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:01.550617+00	t
b658c3ab-c4e2-4c75-a6b9-5daada2f6d42	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:01.570696+00	t
8af9dca4-ac20-4154-95a3-b62ca8bc8e7a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:11.653628+00	t
a80493d3-23a5-432a-8a76-4843f8750b1d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:11.679414+00	t
4ed52c96-32b2-4463-8c9b-d501c274f7c0	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:11.684318+00	t
96501818-cb0b-419f-8778-ac81ebfc5062	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:31.964309+00	t
43622d81-e2f5-44c1-9d9e-225d7c673c61	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:11.686938+00	t
93c6d8a4-69da-48b9-8395-e9dc188f96f3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:21.808173+00	t
15b1d4ce-1529-4879-b1cf-a5e13bc250bf	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:21.833007+00	t
6d63e1f9-aea1-4a57-979a-99543b2a2854	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:21.840309+00	t
c1db5646-0e11-4ab2-b5f1-969124a38181	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:21.873632+00	t
3a45432c-8d70-4b36-8d54-610cd3b57dfc	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:31.943744+00	t
3871af42-6510-4e3a-bb6e-32145e83fe89	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:31.981354+00	t
176c04f6-8eb2-4d54-8641-bd184aa683c6	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:31.99323+00	t
1fbba515-3530-47c6-8aa0-cc3bec2d57dd	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:42.126637+00	t
9a36490d-e440-42ad-9676-8c4d50b19288	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:42.13081+00	t
2f1a18ef-ae25-4473-8110-eac2fa9a58e3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:42.13614+00	t
0a4d41a8-bfeb-404d-a4b0-468c28a36b19	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:42.153656+00	t
5d2a76d9-4166-417c-9456-95359e3336d2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:52.258027+00	t
9087828f-886e-4cba-a36c-03ea1718b994	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:52.259344+00	t
885b0214-9bd1-4b89-a340-1fcad6a6f8ae	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:52.275668+00	t
377baaf0-429f-4cb8-b662-5e3e4c8e5aee	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:00:52.296153+00	t
56e31980-03e7-49e3-9179-d2b59811a6f3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:02.627632+00	t
08e0f993-1b2e-4bab-81ed-348780ea4526	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:02.635461+00	t
56666c84-3920-432d-b867-99b60f71f128	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:02.637258+00	t
90c3b2ba-402e-418c-bf63-c3183b4a1688	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:02.665278+00	t
7d1813b7-19d8-4bf6-b095-26864d0de65a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:12.780514+00	t
021feb09-2dd5-4307-9541-d1db46f31056	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:12.790101+00	t
d325b53d-3171-4626-b98d-4bccb0f68130	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:12.791058+00	t
90b44073-d64b-4af8-8765-a07cf302dc7a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:12.806664+00	t
b3611dfa-e631-426e-9efe-2465d77cef52	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:22.899909+00	t
136deea0-ae39-429d-ae0e-9030af114565	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:22.911068+00	t
f3fdcb21-6d0b-4c76-9abc-538ead23d9a1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:22.912761+00	t
61ff4f9f-f053-4c31-808a-a5a9d1bd68e7	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:22.945981+00	t
53687b02-7e46-4268-ab04-4b76c63ee614	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:33.093245+00	t
310235fc-417d-452a-b492-b7c7034c06ab	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:33.095176+00	t
ee5426d3-af03-4801-9e45-0be676e6e896	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:33.102412+00	t
fca32e9a-c3ca-458a-b192-eacf94edab28	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:33.120472+00	t
5a05ff72-7d47-4ae3-90e2-47043f056647	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:43.187918+00	t
ab11fe8e-0d07-48cb-aeea-4eb8f1372c64	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:43.203576+00	t
e0114665-ee7c-43d1-be37-d04c6c2ad351	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:43.205911+00	t
d8660823-8e87-4379-9974-6642982e76bb	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:43.225195+00	t
901346fb-4eac-432f-8c76-576a48258bb2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:53.350385+00	t
05b8a67a-6490-4cf2-ad21-a57aa217015a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:53.36023+00	t
f5442dae-b323-4a4f-abda-774bba0d0f85	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:53.373181+00	t
6863be02-0f4f-4836-846f-8b994960d3bb	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:01:53.399136+00	t
f4b6ffb6-8d32-4f06-833c-be19f253990a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:03.528693+00	t
64ce0290-b92d-4bf5-ad91-82150e964d55	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:03.549634+00	t
03d7433c-3289-4346-a390-34db7f79d8c2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:03.582803+00	t
89f19e2f-747c-4e51-b6d0-8369bd701f10	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:03.583516+00	t
7461058f-ed3d-499a-b1c7-89ee220868a9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:13.620207+00	t
87df50a8-bfb6-427c-8b0b-56295ff1cc12	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:13.636091+00	t
0926d05a-0e05-4e06-9c07-70411b8165ae	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:13.652212+00	t
5dd0cb90-070b-41b2-b64a-b647b461d8b3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:13.65539+00	t
9999ba45-fba2-41f5-8c90-e10797f0f9b6	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:23.735955+00	t
a170cfe7-56ec-4262-a36e-cb4eaae4304f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:23.738938+00	t
23f1e66e-14af-426e-bcad-aa9d1b96a762	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:23.751013+00	t
7068e08e-ba0e-4883-a333-372a04511c1e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:23.7626+00	t
84c9c91a-863a-4e10-8a47-5f3949d3f599	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:33.870401+00	t
79995acf-f391-4f2a-9883-77052acaa450	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:33.881423+00	t
de50502f-2a06-4580-9c34-cd18f015b2ce	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:33.883965+00	t
0ba26653-fb8d-48b6-a5b8-60e173be5d2a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N		0	complete	2026-02-12 18:02:33.889349+00	t
bac75b73-0e77-4107-9a31-6810f40a53eb	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:02:44.034245+00	t
0036b3bd-1cd2-4063-a1e3-27dc631da50e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:02:44.03766+00	t
3e916b5d-0683-440b-94b6-6adf95669a9b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:02:44.054035+00	t
b61e21d9-1fad-4335-a1a0-b9c806c1644b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:02:44.056585+00	t
f94e041f-a78e-4816-afaf-66a8a58b08bb	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:02:54.192872+00	t
78e3e0fa-1cbb-4ef1-b4a9-70a2a6eb1f38	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:02:54.218531+00	t
550ae681-85a3-4b45-a827-957ca88b3608	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:02:54.220895+00	t
94d56e29-839b-4f1a-8dec-4f71cfab8366	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:02:54.221339+00	t
fcf5b063-8054-4a8b-9460-e99784f153d1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:04.345493+00	t
ca425c85-f7dd-46e1-94aa-c480392f53c9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:04.359842+00	t
4d19a266-2a6e-4866-928b-3de0dd85aba0	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:04.365839+00	t
01052052-bfea-4766-97a1-85ad56ab9325	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:04.372077+00	t
0393bce7-bf4a-458a-8667-a6707bf60e71	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:14.490352+00	t
fba8ab31-d940-41aa-aba8-afa971f504a2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:14.523852+00	t
31214ae3-ae0a-45fd-9c5c-e63606fc5b08	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:14.523699+00	t
736e17b1-59dc-4874-9405-cd041956fe79	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:14.530673+00	t
e850aea0-c917-4978-96ba-76a0277ff532	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:24.661219+00	t
02fd6926-0bc7-4a45-8f58-c345511efc64	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:24.677146+00	t
56939b66-cd18-4402-89b4-0f25572e48f2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:24.695946+00	t
877e7038-84d3-490e-89b4-69f428b55e79	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:24.696534+00	t
ebdd6193-8705-43da-b520-515d0ace5bab	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:34.811521+00	t
a45ce45a-8994-4773-8992-08682f777311	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:34.821472+00	t
d113f3b4-d31a-42be-b655-b10d62681378	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:34.835129+00	t
b98bdcd0-e55f-4b8d-b126-09ba88317706	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:34.841019+00	t
6cd39b0a-b7f0-449d-a647-2695d7422ef0	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:44.981145+00	t
617ffe94-2e95-4444-968e-dbe165fda263	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:44.994961+00	t
fa8f7014-2484-409b-a2fb-8f235d1af8f4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:45.000365+00	t
5d750f3f-0417-4991-90fd-6307057d8c7f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:45.004092+00	t
782ab7ec-90d7-4b24-b832-7ae49f22252b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:55.126535+00	t
d711e34f-3af5-408b-8d79-f4c2fbd2666c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:55.141172+00	t
27e91ff8-5a66-4573-a30a-3468da3e6a24	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:55.15585+00	t
6139db30-fd59-479a-bd17-6aff65b04e10	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:03:55.157015+00	t
de180fa6-209e-4c28-a07f-07f92462ca86	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:05.271599+00	t
a4369e74-80df-48bb-9ba1-48dc8ce18286	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:05.280655+00	t
561a7128-378f-43db-9c2e-e7d2c4ceebae	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:05.294463+00	t
d0c4e680-fef9-42b5-9e2b-c093a089aaaf	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:05.295853+00	t
8256d28a-0ec5-40c4-adff-ffe1b8c0e223	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:15.478011+00	t
c5664fbf-1c84-40a4-8734-0960a362b92e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:15.490521+00	t
0247fe83-b92b-42c6-97bf-29c6a5168049	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:15.489993+00	t
d23f1b3a-a6c8-46a2-ae47-ef7589d66277	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:15.495621+00	t
239f283b-f815-463a-b523-c59ed3f67bf4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:25.661864+00	t
627765c8-45ad-4d1c-9486-1896afd85a2a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:25.671992+00	t
d4a3bfa0-9341-41d7-b6f0-a09d97f26504	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:25.67259+00	t
c1317515-5678-4c30-88b4-791232448506	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:25.687188+00	t
65e3c62b-c7b8-4655-aab3-5d4b1ef0489f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:35.783572+00	t
cf989239-2747-41d1-8866-5bf87e4fe10b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:35.803076+00	t
7a602732-c2f0-440d-9972-6b8d2e0f8a48	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:35.827213+00	t
d9f48554-b2fe-4f41-ab79-b11b9c411abc	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:35.830342+00	t
32482a2f-3c57-4740-8818-8997ee353fcb	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:45.921174+00	t
80ebdbe4-d886-4478-abb9-632d17ce7799	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:45.93805+00	t
b0ca3d8b-e91b-4060-a0f6-479e57e65c56	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:45.953218+00	t
2e776ceb-e420-425b-8ff1-1800e474104d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:45.964953+00	t
264605f7-f8b7-48ed-97fa-f3f2e7bbc0e1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:56.094258+00	t
f42412bf-4e3d-4117-892b-20d925a45690	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:56.146192+00	t
5f8a6e87-cc6b-47b8-b18f-5f7d1fe2ddf9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:56.146497+00	t
4c8fc821-b297-47cd-aee8-123aa43fb773	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:04:56.147733+00	t
1e7940be-e2ba-4010-8ec1-7d0b47f2370f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:06.239766+00	t
5e58973b-0fdc-43a6-bc94-a38e4e3e02ad	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:06.261739+00	t
4c068116-ea82-44c3-bb3f-3c5807545ecc	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:06.270011+00	t
4461e708-86dd-4283-ac5c-9443d30d272f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:06.270273+00	t
cbffd0d9-a6fd-488e-9d63-23e86f2b8830	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:16.369968+00	t
a58c8a3d-3bf4-47b2-a9c5-4dec37f0b001	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:16.414656+00	t
91dd221d-00dc-4162-ae40-179b226caeca	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:16.414469+00	t
3ae19649-d9b2-4ea7-acee-b62a2350b089	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:16.418691+00	t
f79da84e-d857-4e6b-81d9-7e1f59bcda14	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:26.554012+00	t
fb244ab3-5309-429d-8700-437abd5ce63a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:26.564266+00	t
72f26915-2191-4f22-8466-8c2d5ffd8d5d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:26.564893+00	t
8cf93c56-525d-4b15-8584-7ad73a2c628d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:26.566655+00	t
64eb49f6-bf6d-4bd4-b709-c3ca909c2a1e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:36.712058+00	t
34337f01-2f83-4254-987f-dcc87a963c04	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:36.727246+00	t
d4c97288-7236-432e-9abc-cfc7de49468d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:36.733184+00	t
5772e4aa-5f6a-4769-b70a-c71333749793	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:36.739013+00	t
26ffced9-e16f-4ebc-aaa0-68b60c1b1f47	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:46.85814+00	t
309dbd6e-9408-460a-b36f-06131429a10d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:46.867924+00	t
0750be49-c4d6-438d-bd21-46635eadb551	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:46.870121+00	t
53e2263a-554d-4d70-ad39-e8b58829b10c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:46.873848+00	t
a289f830-b389-4275-860f-671cde7294b5	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:57.024593+00	t
3998360d-6575-4765-9f90-240d2bf976e0	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:57.032358+00	t
7e8cc451-6e44-4b9a-a177-d114f4f9760b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:57.048302+00	t
83880dcc-72b5-4be6-a77b-e2528e9dd57d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:05:57.061857+00	t
52395027-1b57-46a6-a567-c2de38f0a4ca	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:07.19122+00	t
c8847528-afa4-423b-b776-9f6f7954fe85	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:07.204624+00	t
d7096935-7ec8-4a61-9c43-9b732810f068	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:07.207946+00	t
9dc36295-d61d-4416-9a67-6e698d2aceb3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:07.236878+00	t
689db3ee-3f12-4f32-b2b5-15b293f80c9d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:17.331432+00	t
a531019c-b9b8-4584-8849-a159570f27a9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:17.353808+00	t
25507d6e-ae69-4e47-8108-8406b31f9c77	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:17.354677+00	t
bbe14544-21c1-4570-a559-d0dcd41f7657	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:17.379807+00	t
fc287d6b-9a5f-4f9f-bc0e-e2fd4acbe457	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:27.655318+00	t
dc8a037c-fe3c-4c3e-9c61-8bdae3a455cf	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:27.674938+00	t
66174818-2c88-4032-83b4-09d16c16ca2b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:27.680884+00	t
73b8bfca-be36-44e3-ae25-acd1e1951675	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:27.685679+00	t
338fc9ba-90b3-49cd-b539-a99a16466125	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:37.835385+00	t
23c9dd1d-44ab-4ed0-b0bc-b07b3383cc00	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:37.851116+00	t
ff588eba-747d-448b-95cc-364be3a377e4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:37.850738+00	t
3de052d2-e90f-4a5e-9cc8-38b5afd8796b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:37.850986+00	t
27906abd-41a4-49d6-8b6a-6204c75edaa6	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:47.923098+00	t
cb489887-62ed-411e-aedb-04272cad45b6	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:47.973648+00	t
cf9c6071-2958-4baa-8b88-b39d661ea136	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:47.980462+00	t
4522d886-97e1-4f0c-a952-6c676fa545dc	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:47.983589+00	t
8b558734-022e-4edb-ac04-b7a238e26d52	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:58.139489+00	t
0bc5282f-f0d8-408d-97dd-6dfed9845ebe	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:58.150331+00	t
2c2e0109-d4e2-4241-87e5-74419e106682	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:58.154949+00	t
709226df-23fd-4f08-b92d-5cefab1cccf3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:06:58.156081+00	t
479cf17a-aaa9-4983-8a62-b28922d012ea	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:08.291464+00	t
bc0a119b-3d7a-401e-a6ac-45fea476ec62	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:08.305794+00	t
14b77b2c-f432-46d9-9a6b-6e848a8741d0	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:08.314626+00	t
7c8d5afd-a70a-4144-b263-379a5ba9cdb9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:08.323113+00	t
c54227b2-e1d7-4898-acb1-fb01009fe9ed	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:18.463227+00	t
45ab298d-8869-45c5-9563-d447541db62e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:18.477551+00	t
d56b0993-0fe0-4748-85ae-2ba71560beb2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:18.505466+00	t
3ff4dcd2-b465-48eb-9298-4cfe1a901e54	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:18.509112+00	t
905aeb5a-059d-4779-bc25-965031c19d18	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:28.638433+00	t
8537ed55-e3cf-475a-89ed-ec6ecd7b1bbd	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:28.650224+00	t
92e2115c-112c-4737-80ea-91005fd375b1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:28.654586+00	t
e0e4f204-3396-4209-96dc-d625d35d296f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:28.658716+00	t
6922719b-2ea0-47f2-9dba-d25c241c42ff	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:38.773087+00	t
8b523447-7f8a-402e-a511-d42044e1533e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:38.792565+00	t
f99092bd-6ab4-4107-91f4-d8b458bea6a5	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:38.79382+00	t
ee15d978-6c99-46be-b1be-4135aae34187	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:38.803292+00	t
e75f842e-4c03-4701-a736-d709eca42494	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:48.908465+00	t
623b596a-f8dd-4b9f-aa60-dc485c473c70	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:48.935746+00	t
56bf4c79-8674-43a8-815e-56d915c6eb5b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:48.939606+00	t
3c4ccd7f-78ca-4ee1-9576-3cbf22a000c4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:48.95253+00	t
d312a914-0c32-4cf9-a1de-16361cb6272b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:59.041014+00	t
cf1578d5-768d-4e85-841e-e36007f8279d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:59.053791+00	t
a30bb48c-79da-4385-aef8-64cb3cc06d31	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:59.075536+00	t
02586be2-84c9-4b6f-8e4c-632bb11cdbee	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:07:59.075275+00	t
94a2e7fd-f476-4262-97df-c28e4b9910aa	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:09.19854+00	t
88300e0f-df3b-46eb-bfa0-26027db2224a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:09.226816+00	t
52e85a23-3974-4047-82f4-4f317559c51f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:09.227952+00	t
0ddbc757-3303-4aeb-b57b-e5b4c2eae4d3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:09.230181+00	t
c642e32c-dec9-442f-a2a7-23011cad665e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:19.341447+00	t
dbdd20a6-2af0-44c6-98ce-4c02ee213189	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:19.356781+00	t
4cf01ca0-4711-4038-8bb1-43d90194439c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:19.38019+00	t
9e816024-3bfa-44eb-a3e3-8bf966c4faec	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:19.393363+00	t
f9a28a4a-d646-457c-b462-c0cf5c8750f1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:29.518564+00	t
cde3f848-8ef4-4a93-b79e-df21c3e529e4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:29.553521+00	t
b84a4edf-22c9-4220-b593-645b65ad98dc	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:29.553307+00	t
9666aa32-66ee-4615-8129-0f07bfadf8a5	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:29.555868+00	t
f91431d7-13fd-4b05-bc00-9da93cc66a0d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:39.657698+00	t
c3227041-8952-444d-937c-94e9e2215d53	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:39.695308+00	t
8c1ee954-9f74-47df-bb2f-83017c5bf224	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:39.733846+00	t
7feaa739-434c-4c26-9781-79d5b0dcf7e7	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:39.741595+00	t
6fd4ac59-c9ec-45b7-998f-f8485ba7eb78	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:49.801321+00	t
f0accb06-cb57-47fc-be0e-802eda896661	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:49.811679+00	t
dd251241-7eab-466b-a8f1-72ace642ba51	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:49.818111+00	t
11fffc63-94e3-49a7-9167-0cfe04766a46	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:49.829822+00	t
8f8a0e91-0a48-4ad6-b56c-e6be11ca1b55	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:08:59.979652+00	t
6f704fcd-4a31-4f24-9266-e8fffd98920e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:00.004994+00	t
43549929-1d6d-4a80-84c2-d70e5ba19c0f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:00.028557+00	t
15ae8f20-1410-442c-a669-bbcd117d3877	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:00.035949+00	t
260af21d-2035-488e-b43d-b771d42f64d4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:10.143813+00	t
9a78ce54-4983-492e-91c0-c13c07d621a4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:10.159542+00	t
18b8d30e-2220-43f6-a8c0-cb5fe9f2a1ba	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:10.160957+00	t
d7f8c7a1-5e1c-4286-b315-f74ecbf907ac	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:10.161266+00	t
287931a2-b042-448a-947d-77159590fc64	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:20.333833+00	t
5aad3baa-0b8a-4568-abe8-79dcec6af094	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:20.344943+00	t
6b8feb76-f4fc-4ff7-af91-a5b6127c48a4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:20.346413+00	t
2a8be3cd-0e05-401e-b6b6-3519103b96cf	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:20.354526+00	t
0cef339a-9d7e-44ab-9105-b5f53a480720	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:30.479437+00	t
d95dfe53-9c7c-4a8f-a667-9b5871a34365	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:30.509513+00	t
4d4415af-8e4e-443d-a33b-3b34b4095d50	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:30.511389+00	t
2d01fb27-b75a-42ca-b3c2-2c6d06401b22	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:30.537941+00	t
bf8fb7cb-dd95-4712-8844-b54159306ffa	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:40.646152+00	t
e436be84-4d12-4b5d-a9d4-594e11562a4f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:40.660757+00	t
318923d6-431d-4ac5-8e06-eed61a9f4640	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:40.681663+00	t
f78bfdcf-48ee-4f07-b7a6-9d7d22fde76c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:40.682904+00	t
e89488ad-7cfb-4aa3-97ef-dc55bc57a4a9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:50.820954+00	t
df33ebe7-ee2c-43dd-87ff-bbf22c1fff3f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:50.841898+00	t
d38b7dcb-c2f4-44eb-b706-c47cf98e3982	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:50.844105+00	t
c5f463d8-88f4-4f9c-9995-234b4760c43b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:09:50.844763+00	t
745cd652-f3eb-4fb9-8c8f-81e5552237fb	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:00.914056+00	t
28807046-4a03-49dc-a381-9e0bb8f2c5c6	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:00.93409+00	t
4d7bf3a5-54df-40ce-b3df-67e8d5d4b7b2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:00.955256+00	t
0dab53c3-4db6-4e2c-9892-9f4ee324aca1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:00.958058+00	t
8d216d5d-3fba-4acf-ae0f-1ef50c577ded	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:11.094678+00	t
d103bd9d-66a8-40b9-a6b2-05c033f26d58	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:11.106422+00	t
7425846a-b60b-4d76-b234-2e55c62d0ff4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:11.110621+00	t
2285f072-bb9e-499e-a7be-c6b3cf5bb99e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:11.111107+00	t
af85e54b-8052-4ef4-b4ae-c86f50d18772	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:21.216368+00	t
9a9627f6-0ec1-4036-abd4-a9db5ba41084	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:21.225026+00	t
4dd9991e-9fa6-424f-930f-ff01eedd17c9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:21.229319+00	t
b8577aa4-9a18-4cac-90f7-c0cb6106f7cf	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:21.244155+00	t
31695bc9-48ec-45b2-817a-717c8e149620	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:31.357111+00	t
a8b7e3d5-911b-43e1-975e-b33775b3cdf0	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:31.365996+00	t
816cd3a2-448a-4417-87be-db0190e6852b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:31.367426+00	t
876fe8c3-0a94-4552-96ed-4ba23a4435be	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:31.370331+00	t
5687b926-1200-4410-bbf3-ca669989ecce	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:41.517628+00	t
baa70fdc-b8d8-494d-b861-c3072271a92f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:41.53881+00	t
cf9a47b3-0ff7-4937-a7be-6ac98f7cb689	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:41.546383+00	t
33db4688-2fab-4c4a-a09a-6ac3c90d98b3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:41.546557+00	t
22276b9f-7b36-4c77-8007-eaff11fcde49	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:51.680163+00	t
677f01e4-4f7b-4bf6-b391-a83e1e4757e2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:51.692747+00	t
abdbfd20-5578-4585-bb95-d974623eb15e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:51.698772+00	t
1659603b-5af2-4787-bec1-55d0bce799ba	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:10:51.702328+00	t
42a01f5f-807e-4254-8931-a031bd5810a0	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:01.835206+00	t
7e4c2117-9e02-4d0c-a8f9-750167098919	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:01.86016+00	t
eb1c50c6-207d-4988-bfe2-7c5c0375dca1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:01.866436+00	t
2bab091e-acfa-4b50-a476-c7be2978bebd	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:01.87184+00	t
85e4a35e-af71-4f32-bd9e-faaaa354555e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:11.989451+00	t
7d8b7b75-5d71-4cec-9387-24a566735890	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:12.008604+00	t
34b81981-99b0-4541-ad17-c610ff053b8b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:12.009781+00	t
478963b6-4dd2-4843-bda1-4df5b016a61d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:12.02541+00	t
83c3e012-4c62-4494-8f26-809f440bc6fd	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:22.140299+00	t
ad7876b4-9871-4565-8ace-8cdc437111be	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:22.162143+00	t
38a49b79-a1f9-4edc-841e-b54dfdb9d587	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:22.166794+00	t
246ac766-1c68-4f1d-9e6c-2faf8ed06b1b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:22.16978+00	t
7c9a8d58-5001-49aa-9369-5258609df617	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:32.268538+00	t
e9530b81-7e66-4f6d-b2f6-102e4a02f3fd	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:32.276486+00	t
d098619d-aaef-44d5-a807-7cb2b1551313	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:32.278748+00	t
10c8f61c-7d31-485a-b7aa-c17ee452206c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:32.292769+00	t
fb2a36a0-f827-4a92-820d-871db0dab14a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:42.423639+00	t
16d2c454-fa10-4da1-94dd-8111389e32fd	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:42.445051+00	t
78f99fd7-548b-4c8c-9f58-c427b7879296	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:42.444703+00	t
8da8309e-af67-4687-8dcb-f595ce54ab13	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:42.457167+00	t
07a01b86-3a3b-4fac-93f9-8db482958b13	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:52.586287+00	t
c8d972b4-77bd-47ac-9e65-be5c637ffe5a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:52.59613+00	t
a06336db-e1dd-4d86-bb55-4afc7c08025b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:52.617016+00	t
e62a03aa-b906-40c0-8947-958b42fab7e5	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:11:52.62941+00	t
1c9b98b0-b5eb-492a-8dad-7a799f8e3d70	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:02.742197+00	t
a8a7487c-73bf-47a5-80cc-c9b8232200a7	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:02.759264+00	t
56e3aba0-9cf0-4cfb-8de0-fd24f283c17e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:02.759382+00	t
97119053-2440-4530-9a4b-e23f707f84a1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:02.759103+00	t
e5b12597-c776-487d-bd76-b5629b56599a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:12.893344+00	t
8aa5b941-a770-4e0c-8827-b4953fb0130c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:12.903296+00	t
22157419-6547-45ff-b3c8-1ee3dbeb328e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:12.905271+00	t
2bd6a5be-52fe-4c3e-add9-ad241d04045a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:12.905862+00	t
e25f8614-22bd-407f-90e8-8c90d739ab77	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:23.074066+00	t
f2db2f28-83bf-4372-9bfe-ac472d67da7b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:23.082069+00	t
adeb4a17-e4dc-4747-a906-7889f46b6828	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:23.094447+00	t
a467269c-668c-4633-81b9-b8c8ff614bac	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:23.097205+00	t
7d286364-1320-4e34-aa4c-62c4bd84c356	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:33.246406+00	t
c9327926-b7c7-4770-af5e-1c34d34cef28	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:33.257627+00	t
e8997fbc-66ee-43f6-8ef4-4539416b5be4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:33.260238+00	t
6a7e640b-980c-42ba-9975-8c91ca2b9029	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:33.270624+00	t
94083f3c-2128-4ca5-ba90-8d945490670e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:43.400968+00	t
c87a114a-abbc-484a-8984-1202ae14208e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:43.428618+00	t
63945f52-615c-47bc-a997-f6f6dc301404	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:43.447349+00	t
070faf20-4e80-4e72-805b-078a38bdd0da	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:43.457717+00	t
9c7a29d4-fac1-48c7-b0a5-478eae428c82	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:53.585517+00	t
f02312aa-eccf-468f-ad7f-dfa650c30660	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:53.603818+00	t
45e866ab-2a67-4f88-aa98-c73e4291ab02	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:53.612484+00	t
e1b6d961-008b-42c7-a8d1-f4343cec82be	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:12:53.621159+00	t
3b627697-8d39-48eb-8f81-de423df80482	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:03.748949+00	t
75696e54-6bc6-4873-a2f7-4ec2c8fad9e8	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:03.758983+00	t
2cf6457d-903d-4fd3-ac68-fc8e8766cc3d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:03.769163+00	t
ccfe3d2c-7066-4575-bfd9-26233bdb5c89	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:03.775958+00	t
35916c70-e597-41dd-a071-2ddfa8d657ea	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:13.87395+00	t
9566b146-ad16-422b-9a49-424258078ac8	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:13.905951+00	t
d73f7802-e706-4f2e-b9a6-ca2bb55dd9b9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:13.906868+00	t
c27f6931-1d61-4c20-998c-c70ccc63404a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:13.91532+00	t
7cbd8d44-9df0-4379-be55-4d7a75655261	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:24.029473+00	t
d993ec42-5a87-4b52-91bd-6e5bb3e6b1c7	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:24.051057+00	t
8d19b4d8-e18e-405d-9535-61947341b912	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:24.055431+00	t
9b70461f-1ae0-4180-a301-2aa6d1fe2d21	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:24.055606+00	t
921ad943-3f8e-4639-b8e4-e9aad17df965	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:34.202821+00	t
7842542f-fe76-4f15-b623-7e204f61ba5b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:34.238132+00	t
be1304f7-cd03-4f73-a566-1f366dbc3c8e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:34.252086+00	t
3810c242-9c75-4937-8275-21dbc60ae6d4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:34.268206+00	t
931ab81e-5107-4d72-997a-e1ff5a663f58	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:44.376124+00	t
aa22e9d3-915a-4f93-947e-134d76e701f1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:44.389032+00	t
86f1bd88-efc8-45d6-9788-fe4a5b9ddc31	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:44.388887+00	t
bdd252d3-f42b-4071-9680-0cfb01c1b524	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:44.412251+00	t
f739989b-228f-41fb-a349-47e1c2e5ca43	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:54.517869+00	t
c56377bc-2893-4d0b-bd3c-7d7979a887ae	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:54.528867+00	t
ddbb2148-b2e2-433f-b395-d321f5ed5bec	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:54.544726+00	t
19ac4b9b-b7b6-4441-8c86-f0f3f6e1ca6c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:13:54.555489+00	t
eeaab389-8764-4ff6-9b00-67ff0dc84abb	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:04.656849+00	t
11eba4c0-1437-40a4-90b4-64c740f6226d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:04.689011+00	t
2e53bb80-019c-404a-82e2-3351f119e903	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:04.693995+00	t
cbb8a1cf-f776-4417-9ad9-c0c85fb89148	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:04.696962+00	t
a21dfb1b-fb5b-471b-85ad-27a6f3a1fa6d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:14.788448+00	t
4d8a01b6-f526-4c5c-b31b-55aa9de82045	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:14.811363+00	t
8082eab7-f8a9-48d7-aa19-31188aea1a7e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:14.821191+00	t
ecdc387c-8a1c-4f3e-b553-3ca8d1540ebe	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:14.821076+00	t
8a8880dc-3a8c-404e-8462-6d1b7670b31c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:25.010357+00	t
7ea4503d-c6ba-44ef-9f2a-414afbae92a3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:25.027912+00	t
75c36e9c-32fd-4c42-a613-5df0ed6d0f29	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:25.062729+00	t
1088bb4f-c864-4f18-a65b-eca3317aab36	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:25.062494+00	t
b4ec71d9-39c1-4cdc-bbec-6bf0b0d8a86b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:35.152147+00	t
9393a30c-b1ae-4b3e-9ef7-9954cf04ab25	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:35.159339+00	t
8c8db92a-8f44-4ac0-9d2d-c0ae4abdf713	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:35.1653+00	t
28b5d530-34ae-4fae-aff3-e00f9538dd1d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:35.173921+00	t
ac9551d8-c9b0-4700-9d83-84c69d7f2c32	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:45.275529+00	t
a3ed6c06-1743-44eb-a610-1410d10d2b61	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:45.29198+00	t
8e06fcfe-5b0a-419d-9b7d-57a78db8fb77	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:45.291747+00	t
60a5e048-a7cf-40cb-b165-4979e068781e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:45.31002+00	t
cb367799-f320-4799-bd35-f646a1d8203b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:55.425302+00	t
188e5c34-3495-46e2-867c-822dcb9ec3a2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:55.435548+00	t
f0284881-1678-42e1-8e61-9624741db717	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:55.439817+00	t
5b9913eb-a27f-44d3-93e3-3c9bd38fbc36	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:14:55.453129+00	t
6eef6bfc-1510-4e72-af2b-ff51e75f5e95	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:05.600458+00	t
b0a9c54e-4b7a-4485-85b9-e7b43c31d4da	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:05.620129+00	t
d779ecc7-bd59-4b35-beac-cd0f986bce27	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:05.621666+00	t
dc46d123-413e-432a-8693-e7fa74c69142	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:05.62555+00	t
5ecbf73c-18b9-44bd-87bb-ca80cba6e24d	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:15.760335+00	t
a92ca45a-10c0-40a4-ad70-2821f84ac972	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:15.774197+00	t
b7b2dc55-4b01-467f-ba90-bae5e2a53169	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:15.790123+00	t
c8abc20d-bc1d-4d65-9732-5254ceaa9d47	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:15.798957+00	t
9176cf65-cf14-4cff-9479-52edd1f90673	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:25.919543+00	t
4ee0765a-89f8-4409-96d6-82cac85d7c5a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:25.929587+00	t
526634de-6347-4f06-b1aa-b52f16d0af0c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:25.931736+00	t
8481f94a-c258-4825-b1e8-e06440e9377f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:25.933182+00	t
61673817-6203-41c8-866f-ce824286da38	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:36.05445+00	t
91cf6493-f507-4cae-85b5-cd1ee39ad2c1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:36.080933+00	t
b1b9f9ac-3bc4-4a8b-866a-07fd83f12486	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:36.083388+00	t
778152b2-783f-45ba-9314-792f1431e935	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:36.096668+00	t
73f1a080-c7d0-470a-aa13-bbea492b1ee2	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:46.207157+00	t
933c45e2-b833-42cb-a95d-af58aae061b9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:46.213773+00	t
03633a5e-03b5-47a1-89f0-f022b5a4d7ba	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:46.231241+00	t
52c6cbd6-98ae-459f-b31c-95197ac633f6	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:46.244796+00	t
6a473cc6-2c5c-4a93-821d-7184b86fd76a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:56.360328+00	t
18de2d0d-81c8-4e2c-aca7-b4820dd62275	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:56.375926+00	t
375217b3-d481-4750-97ac-fd16a229c75a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:56.393303+00	t
171d4f16-c11e-415e-abb4-35bf8850176a	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:15:56.401104+00	t
ada99f02-2de6-400d-8fbc-2052c0b14e7e	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:06.595609+00	t
0dcf4159-ccc1-4725-8189-c2cfd9b81206	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:06.616666+00	t
3e352416-3034-49be-aae3-1a2c246d1d3f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:06.633269+00	t
cf863111-245e-43e4-b55e-84dc17c3a282	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:06.639062+00	t
f80f2eeb-195e-4575-8073-1448976bf45f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:16.700014+00	t
c742d480-36fa-46df-8b3b-17ba3d3ddae4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:16.71184+00	t
4aac05b7-8795-41e3-ba66-b66a0dc05791	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:16.733698+00	t
af5c5cbc-cfe1-46fb-b785-55b6f35887aa	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:16.742555+00	t
faa3bbd7-06ae-4020-ae5a-ac9a5b7419e1	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:26.895715+00	t
d193979a-3ee8-44b9-88b7-1e9a6e90bdd9	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:26.908919+00	t
54263839-2750-425c-923d-c3afc0eefd4b	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:26.922954+00	t
8719754a-e00f-44a7-8e31-ee973dcc5885	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:26.922799+00	t
52435bd1-c813-4bab-a4b7-89efcf3a3dd3	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:37.045698+00	t
109c96de-4dde-4a44-bbf1-35ef96be6497	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:37.064309+00	t
cbfc5ad5-0e5c-402d-922d-cecf377d5875	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:37.072868+00	t
70188daf-b297-4492-a90b-86cdb251f32f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:37.08774+00	t
2b8639cd-0b24-458e-aded-a25f7ba43dc4	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:47.241442+00	t
c4680520-c145-46b2-9c93-e99dcc882c7f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:47.250488+00	t
f6fddd6b-8dc2-4dde-b09f-4c38154c7708	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:47.272093+00	t
ce891c31-243d-4864-8e20-10f4dfb892d6	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:47.273218+00	t
f3e7d4ee-2ab6-4f5f-b7e6-c8fe90621309	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	7a865eea-ddb1-4626-a4f5-c09960f70179	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:57.364271+00	t
29755d87-3d72-4650-91d4-6fdabc996595	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	ff05daa9-b05e-4520-a3aa-84fbe09a05e8	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:57.394645+00	t
386f1e61-a31c-4723-9523-221105fd0019	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	d9567c2f-e369-43f7-9308-034433d92e27	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:57.405213+00	t
94f28947-1283-4b8b-ba7a-a966ece2abb0	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	vagrant\n	\N	\N	\N	0	complete	2026-02-12 18:16:57.404737+00	t
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.tasks (id, tenant_id, agent_id, task_type, embedded_type, embedded_params, run_once, command, args, status, created_at, sent_at, executed_at, completed_at, created_by) FROM stdin;
b9ce7590-021b-470b-b71b-dfe0ecd8351f	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	embedded	file_list	{"path": "/home", "label": "Home (Linux)"}	f	\N	\N	pending	2026-02-12 17:45:55.162986+00	\N	\N	\N	\N
7a865eea-ddb1-4626-a4f5-c09960f70179	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	command	\N	\N	f	whoami	[]	completed	2026-02-12 17:55:59.941856+00	\N	\N	2026-02-12 18:16:57.364271+00	\N
ff05daa9-b05e-4520-a3aa-84fbe09a05e8	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	command	\N	\N	f	whoami	[]	completed	2026-02-12 17:45:36.880316+00	\N	\N	2026-02-12 18:16:57.394645+00	\N
c19aa0c7-d186-49a4-8fb1-e71c4b83f83c	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	command	\N	\N	f	whoami	[]	completed	2026-02-12 17:59:58.572372+00	\N	\N	2026-02-12 18:16:57.404737+00	\N
d9567c2f-e369-43f7-9308-034433d92e27	00000000-0000-0000-0000-000000000001	9e25666f-c470-40f9-9f2f-e947cb12526e	command	\N	\N	f	whoami	[]	completed	2026-02-12 17:58:29.768771+00	\N	\N	2026-02-12 18:16:57.405213+00	\N
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.tenants (id, name, api_key, description, active, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	Default	default-tenant-key	Default tenant created during initial setup	t	2026-02-12 17:38:50.798613+00	2026-02-12 17:38:50.798613+00
\.


--
-- Data for Name: user_tenants; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.user_tenants (user_id, tenant_id, assigned_at) FROM stdin;
da60d9fc-e94d-4d4b-ab5e-9dd6af8da075	00000000-0000-0000-0000-000000000001	2026-02-12 17:41:31.294033+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: gla1v3_app
--

COPY public.users (id, username, password_hash, role, active, totp_secret, totp_enabled, totp_backup_codes, totp_enabled_at, created_at, updated_at) FROM stdin;
da60d9fc-e94d-4d4b-ab5e-9dd6af8da075	admin	$2b$10$ie7JpLOi0axH5tzJZM/IjegQaGoFO.hE7tJimciUSz5EBPRv1OqtC	admin	t	\N	f	\N	\N	2026-02-12 17:41:31.286817+00	2026-02-12 17:41:31.286817+00
\.


--
-- Name: agent_blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gla1v3_app
--

SELECT pg_catalog.setval('public.agent_blacklist_id_seq', 1, false);


--
-- Name: agent_blacklist agent_blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agent_blacklist
    ADD CONSTRAINT agent_blacklist_pkey PRIMARY KEY (id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: results results_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_api_key_key; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_api_key_key UNIQUE (api_key);


--
-- Name: tenants tenants_name_key; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_name_key UNIQUE (name);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: agent_blacklist unique_active_blacklist; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agent_blacklist
    ADD CONSTRAINT unique_active_blacklist UNIQUE (agent_id, tenant_id, revoked);


--
-- Name: user_tenants user_tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_pkey PRIMARY KEY (user_id, tenant_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_agent_blacklist_agent; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agent_blacklist_agent ON public.agent_blacklist USING btree (agent_id);


--
-- Name: idx_agent_blacklist_expires; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agent_blacklist_expires ON public.agent_blacklist USING btree (expires_at) WHERE (expires_at IS NOT NULL);


--
-- Name: idx_agent_blacklist_revoked; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agent_blacklist_revoked ON public.agent_blacklist USING btree (revoked) WHERE (revoked = false);


--
-- Name: idx_agent_blacklist_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agent_blacklist_tenant ON public.agent_blacklist USING btree (tenant_id);


--
-- Name: idx_agents_cert_expiry; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_cert_expiry ON public.agents USING btree (cert_expiry) WHERE (cert_expiry IS NOT NULL);


--
-- Name: idx_agents_cert_id; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_cert_id ON public.agents USING btree (cert_id) WHERE (cert_id IS NOT NULL);


--
-- Name: idx_agents_cert_status; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_cert_status ON public.agents USING btree (cert_status) WHERE (cert_status <> 'active'::text);


--
-- Name: idx_agents_hostname; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_hostname ON public.agents USING btree (tenant_id, hostname);


--
-- Name: idx_agents_last_seen; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_last_seen ON public.agents USING btree (tenant_id, last_seen DESC);


--
-- Name: idx_agents_status; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_status ON public.agents USING btree (tenant_id, status);


--
-- Name: idx_agents_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_agents_tenant ON public.agents USING btree (tenant_id);


--
-- Name: idx_audit_action; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_action ON public.audit_log USING btree (action, "timestamp" DESC);


--
-- Name: idx_audit_resource; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_resource ON public.audit_log USING btree (resource_type, resource_id);


--
-- Name: idx_audit_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_tenant ON public.audit_log USING btree (tenant_id, "timestamp" DESC);


--
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_audit_user ON public.audit_log USING btree (user_id, "timestamp" DESC);


--
-- Name: idx_results_agent; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_agent ON public.results USING btree (tenant_id, agent_id, "timestamp" DESC);


--
-- Name: idx_results_task; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_task ON public.results USING btree (task_id, stream_index);


--
-- Name: idx_results_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_tenant ON public.results USING btree (tenant_id);


--
-- Name: idx_results_timestamp; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_results_timestamp ON public.results USING btree (tenant_id, "timestamp" DESC);


--
-- Name: idx_tasks_agent; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_agent ON public.tasks USING btree (tenant_id, agent_id);


--
-- Name: idx_tasks_created; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_created ON public.tasks USING btree (tenant_id, created_at DESC);


--
-- Name: idx_tasks_pending; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_pending ON public.tasks USING btree (agent_id, status) WHERE (status = 'pending'::text);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_status ON public.tasks USING btree (tenant_id, agent_id, status);


--
-- Name: idx_tasks_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tasks_tenant ON public.tasks USING btree (tenant_id);


--
-- Name: idx_tenants_active; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tenants_active ON public.tenants USING btree (active);


--
-- Name: idx_tenants_api_key; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_tenants_api_key ON public.tenants USING btree (api_key) WHERE (api_key IS NOT NULL);


--
-- Name: idx_user_tenants_tenant; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_user_tenants_tenant ON public.user_tenants USING btree (tenant_id);


--
-- Name: idx_user_tenants_user; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_user_tenants_user ON public.user_tenants USING btree (user_id);


--
-- Name: idx_users_role; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_users_role ON public.users USING btree (role);


--
-- Name: idx_users_totp_enabled; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_users_totp_enabled ON public.users USING btree (totp_enabled);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: gla1v3_app
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: agents update_agents_updated_at; Type: TRIGGER; Schema: public; Owner: gla1v3_app
--

CREATE TRIGGER update_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tenants update_tenants_updated_at; Type: TRIGGER; Schema: public; Owner: gla1v3_app
--

CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: gla1v3_app
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agent_blacklist agent_blacklist_blacklisted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agent_blacklist
    ADD CONSTRAINT agent_blacklist_blacklisted_by_fkey FOREIGN KEY (blacklisted_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agent_blacklist agent_blacklist_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agent_blacklist
    ADD CONSTRAINT agent_blacklist_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: agent_blacklist agent_blacklist_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agent_blacklist
    ADD CONSTRAINT agent_blacklist_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: agents agents_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;


--
-- Name: audit_log audit_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: results results_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: results results_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: results results_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.results
    ADD CONSTRAINT results_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: tasks tasks_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_tenants user_tenants_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: user_tenants user_tenants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: gla1v3_app
--

ALTER TABLE ONLY public.user_tenants
    ADD CONSTRAINT user_tenants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: agents admin_all_agents; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_agents ON public.agents USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: results admin_all_results; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_results ON public.results USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: tasks admin_all_tasks; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_tasks ON public.tasks USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: tenants admin_all_tenants; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY admin_all_tenants ON public.tenants USING ((EXISTS ( SELECT 1
   FROM public.users
  WHERE ((users.id = (current_setting('app.current_user_id'::text, true))::uuid) AND (users.role = 'admin'::text)))));


--
-- Name: agents; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants operator_assigned_tenants; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_assigned_tenants ON public.tenants FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = tenants.id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: agents operator_tenant_agents; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_agents ON public.agents USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = agents.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: results operator_tenant_results; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_results ON public.results USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = results.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: tasks operator_tenant_tasks; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY operator_tenant_tasks ON public.tasks USING ((EXISTS ( SELECT 1
   FROM public.user_tenants
  WHERE ((user_tenants.tenant_id = tasks.tenant_id) AND (user_tenants.user_id = (current_setting('app.current_user_id'::text, true))::uuid)))));


--
-- Name: results; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.results ENABLE ROW LEVEL SECURITY;

--
-- Name: agents service_agent_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_agent_access ON public.agents USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: results service_result_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_result_access ON public.results USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: tasks service_task_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_task_access ON public.tasks USING ((current_setting('app.current_user_id'::text, true) IS NULL)) WITH CHECK ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: tenants service_tenant_access; Type: POLICY; Schema: public; Owner: gla1v3_app
--

CREATE POLICY service_tenant_access ON public.tenants FOR SELECT USING ((current_setting('app.current_user_id'::text, true) IS NULL));


--
-- Name: tasks; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: gla1v3_app
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO gla1v3_api;


--
-- Name: FUNCTION complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.complete_task(task_uuid uuid, task_stdout text, task_stderr text, task_exit_code integer, task_error text) TO gla1v3_api;


--
-- Name: FUNCTION get_expiring_certificates(days_threshold integer); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_expiring_certificates(days_threshold integer) TO gla1v3_api;


--
-- Name: FUNCTION get_pending_tasks_for_agent(agent_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_pending_tasks_for_agent(agent_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION get_tenant_stats(tenant_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_tenant_stats(tenant_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION get_user_tenants(user_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.get_user_tenants(user_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.log_audit(p_user_id uuid, p_tenant_id uuid, p_action text, p_resource_type text, p_resource_id uuid, p_details jsonb, p_ip_address inet, p_user_agent text) TO gla1v3_api;


--
-- Name: FUNCTION mark_stale_agents_inactive(stale_minutes integer); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.mark_stale_agents_inactive(stale_minutes integer) TO gla1v3_api;


--
-- Name: FUNCTION set_current_user(user_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.set_current_user(user_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION update_agent_last_seen(agent_uuid uuid); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.update_agent_last_seen(agent_uuid uuid) TO gla1v3_api;


--
-- Name: FUNCTION update_updated_at_column(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.update_updated_at_column() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v1(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v1() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v1mc(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v1mc() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v3(namespace uuid, name text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v3(namespace uuid, name text) TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v4(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v4() TO gla1v3_api;


--
-- Name: FUNCTION uuid_generate_v5(namespace uuid, name text); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_generate_v5(namespace uuid, name text) TO gla1v3_api;


--
-- Name: FUNCTION uuid_nil(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_nil() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_dns(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_dns() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_oid(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_oid() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_url(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_url() TO gla1v3_api;


--
-- Name: FUNCTION uuid_ns_x500(); Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON FUNCTION public.uuid_ns_x500() TO gla1v3_api;


--
-- Name: TABLE agent_blacklist; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.agent_blacklist TO gla1v3_api;


--
-- Name: SEQUENCE agent_blacklist_id_seq; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT ALL ON SEQUENCE public.agent_blacklist_id_seq TO gla1v3_api;


--
-- Name: TABLE agents; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.agents TO gla1v3_api;


--
-- Name: TABLE audit_log; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.audit_log TO gla1v3_api;


--
-- Name: TABLE results; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.results TO gla1v3_api;


--
-- Name: TABLE tasks; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tasks TO gla1v3_api;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tenants TO gla1v3_api;


--
-- Name: TABLE user_tenants; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_tenants TO gla1v3_api;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: gla1v3_app
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO gla1v3_api;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: gla1v3_app
--

ALTER DEFAULT PRIVILEGES FOR ROLE gla1v3_app IN SCHEMA public GRANT ALL ON SEQUENCES TO gla1v3_api;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: gla1v3_app
--

ALTER DEFAULT PRIVILEGES FOR ROLE gla1v3_app IN SCHEMA public GRANT ALL ON FUNCTIONS TO gla1v3_api;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: gla1v3_app
--

ALTER DEFAULT PRIVILEGES FOR ROLE gla1v3_app IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO gla1v3_api;


--
-- PostgreSQL database dump complete
--

\unrestrict PG2rkblgePHpjlCzS9UjNfgMVrR6BbHdJWTqCcXdvSNJgpaLpbgLkrcGvtFm0Ng

